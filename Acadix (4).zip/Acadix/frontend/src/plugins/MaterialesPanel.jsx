import { useEffect, useState, useRef } from "react";
import "./MaterialesPanel.css";

const API =
  import.meta.env.VITE_API_URL || "http://localhost:3000";

function MaterialesPanel({ token, rol, idCursoMateria }) {
  const [temarios, setTemarios] = useState([]);
  const [bimestres, setBimestres] = useState([]);
  const [materiales, setMateriales] = useState({});
  const [mensaje, setMensaje] = useState("");
  const [cargando, setCargando] = useState(true);

  const [tituloTemario, setTituloTemario] = useState("");
  const [descripcionTemario, setDescripcionTemario] = useState("");
  const [idBimestre, setIdBimestre] = useState("");

  const [temarioEditando, setTemarioEditando] = useState(null);
  const [tituloEditado, setTituloEditado] = useState("");
  const [descripcionEditada, setDescripcionEditada] = useState("");
  const [bimestreEditado, setBimestreEditado] = useState("");

  const [temarioAbierto, setTemarioAbierto] = useState(null);

  const [tituloMaterial, setTituloMaterial] = useState("");
  const [descripcionMaterial, setDescripcionMaterial] = useState("");
  const [archivo, setArchivo] = useState(null);

  const temarioRefs = useRef({});

  const esProfesor = rol?.toLowerCase() === "profesor";

  const headers = {
    Authorization: `Bearer ${token}`
  };


  useEffect(() => {
    if (temarioAbierto === null) return;
        const elemento = temarioRefs.current[temarioAbierto];
        if (elemento) {
            elemento.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });
        }
    }, [temarioAbierto]); 

  async function cargarDatos() {
    try {
      setCargando(true);
      setMensaje("");

      const respuesta = await fetch(
        `${API}/api/plugin-materiales/temarios`,
        { headers }
      );

      const datos = await respuesta.json();

      if (!respuesta.ok) {
        throw new Error(datos.mensaje || "No se pudieron cargar los temarios");
      }

      const filtrados = datos.filter(
        (t) => Number(t.idCursoMateria) === Number(idCursoMateria)
      );

      setTemarios(filtrados);

      if (esProfesor) {
        const respuestaBimestres = await fetch(
          `${API}/api/plugin-materiales/temarios/bimestres`,
          { headers }
        );

        const datosBimestres = await respuestaBimestres.json();

        if (!respuestaBimestres.ok) {
          throw new Error(
            datosBimestres.mensaje || "No se pudieron cargar los bimestres"
          );
        }

        setBimestres(datosBimestres);
      }

      const nuevosMateriales = {};

      await Promise.all(
        filtrados.map(async (temario) => {
          const respuestaMateriales = await fetch(
            `${API}/api/plugin-materiales/materiales/temarios/${temario.id_temario}`,
            { headers }
          );

          const datosMateriales = await respuestaMateriales.json();

          if (respuestaMateriales.ok) {
            nuevosMateriales[temario.id_temario] = datosMateriales;
          } else {
            nuevosMateriales[temario.id_temario] = [];
          }
        })
      );

      setMateriales(nuevosMateriales);

    } catch (error) {
      setMensaje(error.message);
    } finally {
      setCargando(false);
    }
  }

  useEffect(() => {
    console.log("TOKEN:", token);
    console.log("ID CURSO MATERIA:", idCursoMateria);
    console.log("ROL:", rol);
    console.log("PROPS RECIBIDAS:", {
        token,
        idCursoMateria,
        rol
    });

    if (token && idCursoMateria !== undefined && idCursoMateria !== null) {
        cargarDatos();
    } else {
        console.error("Falta el token o el idCursoMateria");
        setCargando(false);
        setMensaje("No se pudo identificar la materia seleccionada.");
    }
}, [token, idCursoMateria, rol]);
  async function crearTemario(e) {
    e.preventDefault();

    try {
      const respuesta = await fetch(
        `${API}/api/plugin-materiales/temarios`,
        {
          method: "POST",
          headers: {
            ...headers,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            titulo: tituloTemario,
            descripcion: descripcionTemario,
            idCursoMateria,
            idBimestre
          })
        }
      );

      const datos = await respuesta.json();

      if (!respuesta.ok) {
        throw new Error(datos.mensaje || "No se pudo crear el temario");
      }

      setTituloTemario("");
      setDescripcionTemario("");
      setIdBimestre("");

      setMensaje("Temario creado correctamente");
      await cargarDatos();

    } catch (error) {
      setMensaje(error.message);
    }
  }

function iniciarEdicionTemario(temario) {
  console.log("TEMARIO A EDITAR:", temario);

  setTemarioEditando(temario.id_temario);
  setTituloEditado(temario.titulo || "");
  setDescripcionEditada(temario.descripcion || "");
  setBimestreEditado(String(temario.idBimestre || ""));

  setMensaje("Se abrió la edición del temario");
}  

function cancelarEdicionTemario() {
  setTemarioEditando(null);
  setTituloEditado("");
  setDescripcionEditada("");
  setBimestreEditado("");
}

async function guardarEdicionTemario(e, idTemario) {
  e.preventDefault();

  try {
    const respuesta = await fetch(
      `${API}/api/plugin-materiales/temarios/${idTemario}`,
      {
        method: "PUT",
        headers: {
          ...headers,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          titulo: tituloEditado,
          descripcion: descripcionEditada,
          idBimestre: bimestreEditado
        })
      }
    );

    const datos = await respuesta.json();

    if (!respuesta.ok) {
      throw new Error(datos.mensaje || "No se pudo editar el temario");
    }

    setMensaje("Temario actualizado correctamente");
    cancelarEdicionTemario();
    await cargarDatos();

    } catch (error) {
    setMensaje(error.message);
  }
}

  async function subirMaterial(e, idTemario) {
    e.preventDefault();

    if (!archivo) {
      setMensaje("Seleccioná un archivo PDF.");
      return;
    }

    const formulario = new FormData();

    formulario.append("titulo", tituloMaterial);
    formulario.append("descripcion", descripcionMaterial);
    formulario.append("archivo", archivo);

    try {
      const respuesta = await fetch(
        `${API}/api/plugin-materiales/materiales/temarios/${idTemario}`,
        {
          method: "POST",
          headers,
          body: formulario
        }
      );

      const datos = await respuesta.json();

      if (!respuesta.ok) {
        throw new Error(datos.mensaje || "No se pudo subir el PDF");
      }

      setTituloMaterial("");
      setDescripcionMaterial("");
      setArchivo(null);

      e.target.reset();

      setMensaje("PDF publicado correctamente");
      await cargarDatos();

    } catch (error) {
      setMensaje(error.message);
    }
  }

  async function abrirPDF(idMaterial) {
    const ventana = window.open("about:blank", "_blank");

    try {
      const respuesta = await fetch(
        `${API}/api/plugin-materiales/materiales/${idMaterial}/archivo`,
        { headers }
      );

      if (!respuesta.ok) {
        const datos = await respuesta.json();
        throw new Error(datos.mensaje || "No se pudo abrir el PDF");
      }

      const blob = await respuesta.blob();
      const url = URL.createObjectURL(blob);

      if (ventana) {
        ventana.location.href = url;
      } else {
        const enlace = document.createElement("a");
        enlace.href = url;
        enlace.download = "material.pdf";
        enlace.click();
      }

    } catch (error) {
      if (ventana) ventana.close();
      setMensaje(error.message);
    }
  }

  async function eliminarMaterial(id) {
    if (!window.confirm("¿Querés eliminar este material?")) return;

    try {
      const respuesta = await fetch(
        `${API}/api/plugin-materiales/materiales/${id}`,
        {
          method: "DELETE",
          headers
        }
      );

      const datos = await respuesta.json();

      if (!respuesta.ok) {
        throw new Error(datos.mensaje || "No se pudo eliminar");
      }

      setMensaje("Material eliminado correctamente");
      await cargarDatos();

    } catch (error) {
      setMensaje(error.message);
    }
  }

  async function editarMaterial(material) {
    const nuevoTitulo = window.prompt(
      "Nuevo título:",
      material.titulo
    );

    if (nuevoTitulo === null || !nuevoTitulo.trim()) return;

    const nuevaDescripcion = window.prompt(
      "Nueva descripción:",
      material.descripcion || ""
    );

    if (nuevaDescripcion === null) return;

    try {
      const respuesta = await fetch(
        `${API}/api/plugin-materiales/materiales/${material.id_material}`,
        {
          method: "PUT",
          headers: {
            ...headers,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            titulo: nuevoTitulo,
            descripcion: nuevaDescripcion
          })
        }
      );

      const datos = await respuesta.json();

      if (!respuesta.ok) {
        throw new Error(datos.mensaje || "No se pudo editar");
      }

      setMensaje("Material actualizado correctamente");
      await cargarDatos();

    } catch (error) {
      setMensaje(error.message);
    }
  }

  async function eliminarTemario(id) {
    if (!window.confirm("¿Querés eliminar este temario?")) return;

    try {
      const respuesta = await fetch(
        `${API}/api/plugin-materiales/temarios/${id}`,
        {
          method: "DELETE",
          headers
        }
      );

      const datos = await respuesta.json();

      if (!respuesta.ok) {
        throw new Error(datos.mensaje || "No se pudo eliminar el temario");
      }

      setMensaje("Temario eliminado correctamente");
      await cargarDatos();

    } catch (error) {
      setMensaje(error.message);
    }
  }

  if (cargando) {
    return <p>Cargando materiales...</p>;
  }

  return (
    <section className="plugin-materiales">

      <h2>Temarios y materiales</h2>

      {mensaje && (
        <p className="mensaje-materiales">{mensaje}</p>
      )}

      {esProfesor && (
        <form className="form-temario" onSubmit={crearTemario}>
          <h3>Crear nuevo temario</h3>

          <input
            type="text"
            placeholder="Título del temario"
            value={tituloTemario}
            onChange={(e) => setTituloTemario(e.target.value)}
            required
          />

          <textarea
            placeholder="Descripción"
            value={descripcionTemario}
            onChange={(e) => setDescripcionTemario(e.target.value)}
          />

          <select
            value={idBimestre}
            onChange={(e) => setIdBimestre(e.target.value)}
            required
          >
            <option value="">Seleccionar bimestre</option>

            {bimestres.map((bimestre) => (
              <option
                key={bimestre.id_bime}
                value={bimestre.id_bime}
              >
                {bimestre.num}
              </option>
            ))}
          </select>

          <button type="submit">
            Crear temario
          </button>
        </form>
      )}

      <div className="lista-temarios">

        {temarios.length === 0 ? (
          <p>Todavía no hay temarios para esta materia.</p>
        ) : (

          temarios.map((temario) => (

            <article
            className="tarjeta-temario"
            key={temario.id_temario}
            ref={(elemento) => {
                temarioRefs.current[temario.id_temario] = elemento;
                }}
                >

              <div className="encabezado-temario">

                <button
                  className="boton-temario"
                  onClick={() =>
                    setTemarioAbierto(
                      temarioAbierto === temario.id_temario
                        ? null
                        : temario.id_temario
                    )
                  }
                >
                  📁 {temario.titulo}
                  {temario.bimestre && ` - ${temario.bimestre}`}
                </button>

                {esProfesor && (
                <>
                <button
                className="boton-editar-temario"
                onClick={() => iniciarEdicionTemario(temario)}
                >
                  Editar temario
                  </button>
                  <button
                  className="boton-eliminar"
                  onClick={() => eliminarTemario(temario.id_temario)}
                  >
                    Eliminar temario
                    </button>
                    </>
                  )}

              </div>
              {esProfesor && temarioEditando === temario.id_temario && (
                <form
                className="form-editar-temario"
                onSubmit={(e) => guardarEdicionTemario(e, temario.id_temario)}
                >
                  <h4>Editar temario</h4>
                  <label>Título:</label>
                  <input
                  type="text"
                  value={tituloEditado}
                  onChange={(e) => setTituloEditado(e.target.value)}
                  required
                  />
                  
                  <label>Descripción:</label>
                  <textarea
                  value={descripcionEditada}
                  onChange={(e) => setDescripcionEditada(e.target.value)}
                  />
                  <label>Bimestre:</label>
                  <select
                  value={bimestreEditado}
                  onChange={(e) => setBimestreEditado(e.target.value)}
                  required
                  >
                    <option value="">Seleccionar bimestre</option>
                    
                    {bimestres.map((bimestre) => (
                      <option
                      key={bimestre.id_bime}
                      value={bimestre.id_bime}
                      >
                        {bimestre.num}
                        </option>
                      ))}
                      </select>
                      <button type="submit">Guardar cambios</button>
                      <button type="button" onClick={cancelarEdicionTemario}>
                        Cancelar
                        </button>
                        </form>
                      )}

              {temarioAbierto === temario.id_temario && (

                <div className="contenido-temario">

                  {temario.descripcion && (
                    <p>{temario.descripcion}</p>
                  )}

                  <h4>Archivos PDF</h4>

                  {(materiales[temario.id_temario] || []).length === 0 ? (
                    <p>No hay archivos publicados.</p>
                  ) : (

                    materiales[temario.id_temario].map((material) => (

                      <div
                        className="fila-material"
                        key={material.id_material}
                      >
                        <span>📄 {material.titulo}</span>

                        <button
                          onClick={() => abrirPDF(material.id_material)}
                        >
                          Abrir PDF
                        </button>

                        {esProfesor && (
                          <>
                            <button
                              onClick={() => editarMaterial(material)}
                            >
                              Editar
                            </button>

                            <button
                              onClick={() =>
                                eliminarMaterial(material.id_material)
                              }
                            >
                              Eliminar
                            </button>
                          </>
                        )}
                      </div>

                    ))
                  )}

                  {esProfesor && (
                    <form
                      className="form-material"
                      onSubmit={(e) => subirMaterial(e, temario.id_temario)}
                    >
                      <h4>Publicar un PDF</h4>

                      <input
                        type="text"
                        placeholder="Título del material"
                        value={tituloMaterial}
                        onChange={(e) => setTituloMaterial(e.target.value)}
                        required
                      />

                      <textarea
                        placeholder="Descripción"
                        value={descripcionMaterial}
                        onChange={(e) =>
                          setDescripcionMaterial(e.target.value)
                        }
                      />

                      <input
                        type="file"
                        accept="application/pdf,.pdf"
                        onChange={(e) => setArchivo(e.target.files[0])}
                        required
                      />

                      <button type="submit">
                        Subir PDF
                      </button>
                    </form>
                  )}

                </div>
              )}

            </article>

          ))
        )}

      </div>

    </section>
  );
}

export default MaterialesPanel;
