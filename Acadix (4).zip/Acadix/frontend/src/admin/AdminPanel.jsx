import { BrowserRouter, Routes, Route, NavLink, Navigate } from "react-router-dom";
import AlumnosPanel from "./AlumnosPanel";
import DocentesPanel from "./DocentesPanel";
import MateriasPanel from "./MateriasPanel";
import CursosPanel from "./CursosPanel";

// ==========================================
// AdminPanel
// ==========================================
// Reemplaza el bloque "panelAdmin" que antes vivía inline
// dentro de App.jsx. Usa react-router SOLO acá adentro
// (rutas /admin/...), el resto de la app sigue navegando
// por el estado "pantalla" como antes.
// ==========================================

function AdminPanel({ usuario, token, onCerrarSesion }) {
    const cerrarSesion = () => {
        // Al salir del admin, se resetea la URL para que un
        // refresh no quede apuntando a /admin/algo mientras
        // el resto de la app ya volvió a la pantalla "inicio".
        window.history.replaceState(null, "", "/");
        onCerrarSesion();
    };

    return (
        <BrowserRouter>
            <div className="pantalla pantalla-admin">
                <div className="contenedor panel panel-admin">
                    <h1>ACADIX</h1>

                    <div className="admin-lateral">
                        <div className="titulo-admin">PANEL DE ADMINISTRADOR</div>

                        <div className="nombre-admin">
                            {usuario.nombre} {usuario.apellido}
                        </div>

                        <NavLink
                            to="/admin/alumnos"
                            className={({ isActive }) => `boton-admin${isActive ? " activo" : ""}`}
                        >
                            Gestionar alumnos
                        </NavLink>

                        <NavLink
                            to="/admin/docentes"
                            className={({ isActive }) => `boton-admin${isActive ? " activo" : ""}`}
                        >
                            Gestionar docentes
                        </NavLink>

                        <NavLink
                            to="/admin/materias"
                            className={({ isActive }) => `boton-admin${isActive ? " activo" : ""}`}
                        >
                            Gestionar materias
                        </NavLink>

                        <NavLink
                            to="/admin/cursos"
                            className={({ isActive }) => `boton-admin${isActive ? " activo" : ""}`}
                        >
                            Gestionar cursos
                        </NavLink>

                        <button className="boton-admin" disabled title="Próximamente">
                            Gestionar temarios (próximamente)
                        </button>
                    </div>

                    <div className="admin-contenido">
                        <Routes>
                            <Route path="/admin" element={<Navigate to="/admin/alumnos" replace />} />
                            <Route path="/admin/alumnos" element={<AlumnosPanel token={token} />} />
                            <Route path="/admin/docentes" element={<DocentesPanel token={token} />} />
                            <Route path="/admin/materias" element={<MateriasPanel token={token} />} />
                            <Route path="/admin/cursos" element={<CursosPanel token={token} />} />
                            <Route path="*" element={<Navigate to="/admin/alumnos" replace />} />
                        </Routes>
                    </div>

                    <button className="cerrar-admin" onClick={cerrarSesion}>
                        Cerrar sesión
                    </button>
                </div>
            </div>
        </BrowserRouter>
    );
}

export default AdminPanel;
