import { useState, useEffect } from "react";
import useCrud from "../hooks/useCrud";
import api from "../services/api";
import Tabla from "./components/Tabla";
import FormularioModal from "./components/FormularioModal";

function CursosPanel({ token }) {
    const { items: cursos, cargando, error, crear, editar, eliminar } = useCrud("/api/cursos", token);

    const [anios, setAnios] = useState([]);
    const [divisiones, setDivisiones] = useState([]);
    const [turnos, setTurnos] = useState([]);

    const [mostrarForm, setMostrarForm] = useState(false);
    const [editando, setEditando] = useState(null);

    useEffect(() => {
        api.get("/api/catalogos/anios", token).then(setAnios).catch(() => setAnios([]));
        api.get("/api/catalogos/divisiones", token).then(setDivisiones).catch(() => setDivisiones([]));
        api.get("/api/catalogos/turnos", token).then(setTurnos).catch(() => setTurnos([]));
    }, [token]);

    const campos = [
        {
            name: "idAnio",
            label: "Año",
            type: "select",
            opciones: anios.map((a) => ({ value: a.id, label: a.anio }))
        },
        {
            name: "idDivision",
            label: "División",
            type: "select",
            opciones: divisiones.map((d) => ({ value: d.id, label: d.nombre }))
        },
        {
            name: "idTurno",
            label: "Turno",
            type: "select",
            opciones: turnos.map((t) => ({ value: t.id, label: t.nombre }))
        }
    ];

    const manejarCrear = async (datos) => {
        const ok = await crear(datos);
        if (ok) setMostrarForm(false);
    };

    const manejarEditar = async (datos) => {
        const ok = await editar(editando.id, datos);
        if (ok) setEditando(null);
    };

    const manejarEliminar = (fila) => {
        if (window.confirm(`¿Eliminar el curso "${fila.anio} ${fila.division}"?`)) {
            eliminar(fila.id);
        }
    };

    return (
        <div>
            <h2>Gestión de Cursos</h2>

            {error && <p className="error-admin">{error}</p>}

            <button onClick={() => setMostrarForm(true)}>Agregar curso</button>

            {cargando ? (
                <p>Cargando...</p>
            ) : (
                <Tabla
                    columnas={[
                        { key: "anio", label: "Año" },
                        { key: "division", label: "División" },
                        { key: "turno", label: "Turno" }
                    ]}
                    filas={cursos}
                    onEditar={(fila) => setEditando(fila)}
                    onEliminar={manejarEliminar}
                />
            )}

            {mostrarForm && (
                <FormularioModal
                    titulo="Agregar curso"
                    campos={campos}
                    onGuardar={manejarCrear}
                    onCancelar={() => setMostrarForm(false)}
                />
            )}

            {editando && (
                <FormularioModal
                    titulo="Editar curso"
                    campos={campos}
                    valoresIniciales={editando}
                    onGuardar={manejarEditar}
                    onCancelar={() => setEditando(null)}
                />
            )}
        </div>
    );
}

export default CursosPanel;
