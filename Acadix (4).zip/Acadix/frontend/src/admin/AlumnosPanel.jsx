import { useState, useEffect } from "react";
import useCrud from "../hooks/useCrud";
import api from "../services/api";
import Tabla from "./components/Tabla";
import FormularioModal from "./components/FormularioModal";

function AlumnosPanel({ token }) {
    const { items: alumnos, cargando, error, crear, editar, eliminar } = useCrud("/api/alumnos", token);

    const [cursos, setCursos] = useState([]);
    const [mostrarForm, setMostrarForm] = useState(false);
    const [editando, setEditando] = useState(null);

    useEffect(() => {
        api.get("/api/cursos", token)
            .then(setCursos)
            .catch(() => setCursos([]));
    }, [token]);

    const opcionesCurso = cursos.map((c) => ({
        value: c.id,
        label: `${c.anio || "-"} ${c.division || "-"} (${c.turno || "-"})`
    }));

    const camposCrear = [
        { name: "nombre", label: "Nombre", type: "text" },
        { name: "apellido", label: "Apellido", type: "text" },
        { name: "email", label: "Email", type: "email" },
        { name: "password", label: "Contraseña", type: "password" },
        { name: "curso", label: "Curso", type: "select", opciones: opcionesCurso }
    ];

    const camposEditar = [
        { name: "nombre", label: "Nombre", type: "text" },
        { name: "apellido", label: "Apellido", type: "text" },
        { name: "email", label: "Email", type: "email" }
    ];

    const manejarCrear = async (datos) => {
        const ok = await crear(datos);
        if (ok) setMostrarForm(false);
    };

    const manejarEditar = async (datos) => {
        const ok = await editar(editando.id_alu, datos);
        if (ok) setEditando(null);
    };

    const manejarEliminar = (fila) => {
        if (window.confirm(`¿Eliminar a ${fila.nombre} ${fila.apellido}?`)) {
            eliminar(fila.id_alu);
        }
    };

    return (
        <div>
            <h2>Gestión de Alumnos</h2>

            {error && <p className="error-admin">{error}</p>}

            <button onClick={() => setMostrarForm(true)}>Agregar alumno</button>

            {cargando ? (
                <p>Cargando...</p>
            ) : (
                <Tabla
                    columnas={[
                        { key: "nombre", label: "Nombre" },
                        { key: "apellido", label: "Apellido" },
                        { key: "email", label: "Email" }
                    ]}
                    filas={alumnos.map((a) => ({ ...a, id: a.id_alu }))}
                    onEditar={(fila) => setEditando(fila)}
                    onEliminar={manejarEliminar}
                />
            )}

            {mostrarForm && (
                <FormularioModal
                    titulo="Agregar alumno"
                    campos={camposCrear}
                    onGuardar={manejarCrear}
                    onCancelar={() => setMostrarForm(false)}
                />
            )}

            {editando && (
                <FormularioModal
                    titulo="Editar alumno"
                    campos={camposEditar}
                    valoresIniciales={editando}
                    onGuardar={manejarEditar}
                    onCancelar={() => setEditando(null)}
                />
            )}
        </div>
    );
}

export default AlumnosPanel;
