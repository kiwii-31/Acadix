// ==========================================
// Tabla genérica
// ==========================================
// columnas: [{ key: "nombre", label: "Nombre" }, ...]
// filas: array de objetos (cada uno debe tener "id")
// onEditar / onEliminar: opcionales, si no se pasan no se
// muestra esa acción.
// ==========================================

function Tabla({ columnas, filas, onEditar, onEliminar }) {
    if (filas.length === 0) {
        return <p>No hay registros.</p>;
    }

    return (
        <table>
            <thead>
                <tr>
                    {columnas.map((col) => (
                        <th key={col.key}>{col.label}</th>
                    ))}
                    {(onEditar || onEliminar) && <th>Acciones</th>}
                </tr>
            </thead>

            <tbody>
                {filas.map((fila) => (
                    <tr key={fila.id}>
                        {columnas.map((col) => (
                            <td key={col.key}>{fila[col.key]}</td>
                        ))}

                        {(onEditar || onEliminar) && (
                            <td>
                                {onEditar && (
                                    <button onClick={() => onEditar(fila)}>
                                        Editar
                                    </button>
                                )}

                                {onEliminar && (
                                    <button onClick={() => onEliminar(fila)}>
                                        Eliminar
                                    </button>
                                )}
                            </td>
                        )}
                    </tr>
                ))}
            </tbody>
        </table>
    );
}

export default Tabla;
