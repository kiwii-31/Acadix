import { useState } from "react";

// ==========================================
// FormularioModal
// ==========================================
// campos: [
//   { name: "nombre", label: "Nombre", type: "text" },
//   { name: "idTurno", label: "Turno", type: "select", opciones: [{value, label}] },
// ]
// valoresIniciales: objeto con los valores de arranque (para editar)
// onGuardar(datos): se llama al enviar el form
// onCancelar(): se llama al cerrar sin guardar
// ==========================================

function FormularioModal({ titulo, campos, valoresIniciales = {}, onGuardar, onCancelar }) {
    const [valores, setValores] = useState(valoresIniciales);
    const [enviando, setEnviando] = useState(false);

    const actualizarCampo = (name, value) => {
        setValores((prev) => ({ ...prev, [name]: value }));
    };

    const manejarEnvio = async (e) => {
        e.preventDefault();
        setEnviando(true);

        await onGuardar(valores);

        setEnviando(false);
    };

    return (
        <div className="modal-overlay">
            <form className="modal-contenido" onSubmit={manejarEnvio}>
                <h3>{titulo}</h3>

                {campos.map((campo) => (
                    <div className="campo-formulario" key={campo.name}>
                        <label>{campo.label}</label>

                        {campo.type === "select" ? (
                            <select
                                value={valores[campo.name] ?? ""}
                                onChange={(e) => actualizarCampo(campo.name, e.target.value)}
                                required
                            >
                                <option value="" disabled>
                                    Seleccionar...
                                </option>

                                {campo.opciones.map((opcion) => (
                                    <option key={opcion.value} value={opcion.value}>
                                        {opcion.label}
                                    </option>
                                ))}
                            </select>
                        ) : (
                            <input
                                type={campo.type || "text"}
                                value={valores[campo.name] ?? ""}
                                onChange={(e) => actualizarCampo(campo.name, e.target.value)}
                                required
                            />
                        )}
                    </div>
                ))}

                <div className="acciones-formulario">
                    <button type="submit" disabled={enviando}>
                        {enviando ? "Guardando..." : "Guardar"}
                    </button>

                    <button type="button" onClick={onCancelar} disabled={enviando}>
                        Cancelar
                    </button>
                </div>
            </form>
        </div>
    );
}

export default FormularioModal;
