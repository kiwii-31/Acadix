import { useState } from "react";
import useCrud from "../hooks/useCrud";
import Tabla from "./components/Tabla";
import FormularioModal from "./components/FormularioModal";

function DocentesPanel({ token }) {
    const { items: docentes, cargando, error, crear, editar, eliminar } = useCrud("/api/docentes", token);

    const [mostrarForm, setMostrarForm] = useState(false);
    const [editando, setEditando] = useState(null);

    const camposCrear = [
        { name: "nombre", label: "Nombre", type: "text" },
        { name: "apellido", label: "Apellido", type: "text" },
        { name: "email", label: "Email", type: "email" },
        { name: "password", label: "Contraseña", type: "password" }
    ];

    const camposEditar = [
        { name: "nombre", label: "Nombre", type: "text" },
        { name: "apellido", label: "Apellido", type: "text" },
        { name: "email", label: "Email", type: "email" }
    ];

    const manejarCrear = async (datos) => {
        const ok = await crear(datos);
        if (ok) setMostrarForm(false);
    };

    const manejarEditar = async (datos) => {
        const ok = await editar(editando.id, datos);
        if (ok) setEditando(null);
    };

    const manejarEliminar = (fila) => {
        if (window.confirm(`¿Eliminar a ${fila.nombre} ${fila.apellido}?`)) {
            eliminar(fila.id);
        }
    };

    return (
        <div>
            <h2>Gestión de Docentes</h2>

            {error && <p className="error-admin">{error}</p>}

            <button onClick={() => setMostrarForm(true)}>Agregar docente</button>

            {cargando ? (
                <p>Cargando...</p>
            ) : (
                <Tabla
                    columnas={[
                        { key: "nombre", label: "Nombre" },
                        { key: "apellido", label: "Apellido" },
                        { key: "email", label: "Email" }
                    ]}
                    filas={docentes}
                    onEditar={(fila) => setEditando(fila)}
                    onEliminar={manejarEliminar}
                />
            )}

            {mostrarForm && (
                <FormularioModal
                    titulo="Agregar docente"
                    campos={camposCrear}
                    onGuardar={manejarCrear}
                    onCancelar={() => setMostrarForm(false)}
                />
            )}

            {editando && (
                <FormularioModal
                    titulo="Editar docente"
                    campos={camposEditar}
                    valoresIniciales={editando}
                    onGuardar={manejarEditar}
                    onCancelar={() => setEditando(null)}
                />
            )}
        </div>
    );
}

export default DocentesPanel;
