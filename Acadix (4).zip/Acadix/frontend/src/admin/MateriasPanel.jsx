import { useState } from "react";
import useCrud from "../hooks/useCrud";
import Tabla from "./components/Tabla";
import FormularioModal from "./components/FormularioModal";

function MateriasPanel({ token }) {
    const { items: materias, cargando, error, crear, editar, eliminar } = useCrud("/api/materias", token);

    const [mostrarForm, setMostrarForm] = useState(false);
    const [editando, setEditando] = useState(null);

    const campos = [{ name: "nombre", label: "Nombre", type: "text" }];

    const manejarCrear = async (datos) => {
        const ok = await crear(datos);
        if (ok) setMostrarForm(false);
    };

    const manejarEditar = async (datos) => {
        const ok = await editar(editando.id, datos);
        if (ok) setEditando(null);
    };

    const manejarEliminar = (fila) => {
        if (window.confirm(`¿Eliminar la materia "${fila.nombre}"?`)) {
            eliminar(fila.id);
        }
    };

    return (
        <div>
            <h2>Gestión de Materias</h2>

            {error && <p className="error-admin">{error}</p>}

            <button onClick={() => setMostrarForm(true)}>Agregar materia</button>

            {cargando ? (
                <p>Cargando...</p>
            ) : (
                <Tabla
                    columnas={[{ key: "nombre", label: "Nombre" }]}
                    filas={materias}
                    onEditar={(fila) => setEditando(fila)}
                    onEliminar={manejarEliminar}
                />
            )}

            {mostrarForm && (
                <FormularioModal
                    titulo="Agregar materia"
                    campos={campos}
                    onGuardar={manejarCrear}
                    onCancelar={() => setMostrarForm(false)}
                />
            )}

            {editando && (
                <FormularioModal
                    titulo="Editar materia"
                    campos={campos}
                    valoresIniciales={editando}
                    onGuardar={manejarEditar}
                    onCancelar={() => setEditando(null)}
                />
            )}
        </div>
    );
}

export default MateriasPanel;
