import { useState } from "react";
import "./App.css";
import AdminPanel from "./admin/AdminPanel";
import MaterialesPanel from "./plugins/MaterialesPanel";

function App() {
  // =====================================================
  // ESTADOS GENERALES
  // =====================================================

  const [pantalla, setPantalla] = useState("inicio");
  const [rol, setRol] = useState("");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [usuario, setUsuario] = useState(null);
  const [token, setToken] = useState(null);
  const [materiaSeleccionada, setMateriaSeleccionada] = useState(null);

  const [mensaje, setMensaje] = useState("");
  const [cargando, setCargando] = useState(false);
  const [loginCorrecto, setLoginCorrecto] = useState(false);

  // =====================================================
  // DATOS DEL REGISTRO
  // =====================================================

  const [nombreRegistro, setNombreRegistro] = useState("");
  const [apellidoRegistro, setApellidoRegistro] = useState("");
  const [emailRegistro, setEmailRegistro] = useState("");
  const [passwordRegistro, setPasswordRegistro] = useState("");
  const [codigoRegistro, setCodigoRegistro] = useState("");
  const [cursoRegistro, setCursoRegistro] = useState("");

  // =====================================================
  // FILTROS DEL PROFESOR
  // =====================================================

  const [filtroAnio, setFiltroAnio] = useState("");
  const [filtroDivision, setFiltroDivision] = useState("");
  const [filtroTurno, setFiltroTurno] = useState("");

  // =====================================================
  // SELECCIONAR ROL PARA LOGIN
  // =====================================================

  const seleccionarRol = (rolSeleccionado) => {
    setRol(rolSeleccionado);

    setMensaje("");
    setEmail("");
    setPassword("");

    setLoginCorrecto(false);
    setUsuario(null);

    setFiltroAnio("");
    setFiltroDivision("");
    setFiltroTurno("");

    setPantalla("login");
  };

  // =====================================================
  // SELECCIONAR ROL PARA REGISTRO
  // =====================================================

  const seleccionarRolRegistro = (rolSeleccionado) => {
    setRol(rolSeleccionado);

    limpiarRegistro();

    setPantalla(
      rolSeleccionado === "alumno"
        ? "registroAlumno"
        : "registroProfesor"
    );
  };

  // =====================================================
  // LIMPIAR DATOS DEL REGISTRO
  // =====================================================

  const limpiarRegistro = () => {
    setNombreRegistro("");
    setApellidoRegistro("");
    setEmailRegistro("");
    setPasswordRegistro("");
    setCodigoRegistro("");
    setCursoRegistro("");
    setMensaje("");
  };

  // =====================================================
  // REGISTRAR CUENTA
  // =====================================================

  const registrarCuenta = async (e) => {
    e.preventDefault();

    setMensaje("");
    setCargando(true);

    try {
      let url = "";
      let datos = {};

      // -----------------------------------------------
      // REGISTRO ALUMNO
      // -----------------------------------------------

      if (rol === "alumno") {
        url = "http://localhost:3000/api/auth/registro/alumno";

        datos = {
          nombre: nombreRegistro,
          apellido: apellidoRegistro,
          email: emailRegistro,
          password: passwordRegistro,
          codigo: codigoRegistro,
          curso: cursoRegistro,
        };
      }

      // -----------------------------------------------
      // REGISTRO PROFESOR
      // -----------------------------------------------

      if (rol === "profesor") {
        url = "http://localhost:3000/api/auth/registro/docente";

        datos = {
          nombre: nombreRegistro,
          apellido: apellidoRegistro,
          email: emailRegistro,
          password: passwordRegistro,
          codigo: codigoRegistro,
        };
      }

      const respuesta = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(datos),
      });

      const resultado = await respuesta.json();

      if (!respuesta.ok) {
        setMensaje(resultado.mensaje || "No se pudo crear la cuenta");
        return;
      }

      // Cuenta creada correctamente
      setMensaje(resultado.mensaje);

      alert(
        "Cuenta creada correctamente. Ahora podés iniciar sesión."
      );

      // Limpiar formulario
      limpiarRegistro();

      // Ir al login con el rol correspondiente
      setRol(rol);
      setPantalla("login");

    } catch (error) {
      console.error("Error al registrar:", error);

      setMensaje(
        "No se pudo conectar con el servidor"
      );

    } finally {
      setCargando(false);
    }
  };

  // =====================================================
  // INICIAR SESIÓN
  // =====================================================

  const iniciarSesion = async (e) => {
    e.preventDefault();

    setMensaje("");
    setLoginCorrecto(false);
    setCargando(true);

    try {
      const respuesta = await fetch(
        "http://localhost:3000/api/auth/login",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email,
            password,
            rol,
          }),
        }
      );

      const datos = await respuesta.json();

      if (!respuesta.ok) {
        setMensaje(
          datos.mensaje || "Error al iniciar sesión"
        );
        return;
      }

      console.log(
        "Usuario logueado:",
        datos.usuario
      );

      console.log(
        "MATERIAS COMPLETAS:",
        JSON.stringify(datos.usuario.materias, null, 2)
      );

      setUsuario(datos.usuario);
      setToken(datos.token || null);

      setMensaje(
        `¡Bienvenido/a ${datos.usuario.nombre}!`
      );

      setLoginCorrecto(true);

      setFiltroAnio("");
      setFiltroDivision("");
      setFiltroTurno("");

      // Ir al panel correspondiente
      if (datos.usuario.rol.toLowerCase() === "alumno") {
        setPantalla("panelAlumno");

      } else if (datos.usuario.rol.toLowerCase() === "profesor") {
        setPantalla("panelProfesor");

      } else if (datos.usuario.rol.toLowerCase() === "administrador") {
        setPantalla("panelAdmin");

      } else {
        setMensaje("Rol no reconocido");
      }

    } catch (error) {

      console.error("Error:", error);

      setMensaje(
        "No se pudo conectar con el servidor"
      );

    } finally {
      setCargando(false);
    }
  };

  // =====================================================
  // CERRAR SESIÓN
  // =====================================================

  const cerrarSesion = () => {
    setPantalla("inicio");

    setRol("");
    setEmail("");
    setPassword("");

    setUsuario(null);
    setToken(null);

    setMensaje("");
    setLoginCorrecto(false);

    setFiltroAnio("");
    setFiltroDivision("");
    setFiltroTurno("");
  };

  // =====================================================
  // VOLVER AL INICIO
  // =====================================================

  const volverInicio = () => {
    setPantalla("inicio");

    setRol("");
    setEmail("");
    setPassword("");

    setUsuario(null);
    setToken(null);

    limpiarRegistro();

    setMensaje("");
    setLoginCorrecto(false);

    setFiltroAnio("");
    setFiltroDivision("");
    setFiltroTurno("");
  };

  // =====================================================
  // DATOS DEL PROFESOR
  // =====================================================

  const materiasProfesor = usuario?.materias || [];

  const aniosDisponibles = [
    ...new Set(
      materiasProfesor.map(
        (materia) => materia.curso
      )
    ),
  ];

  const divisionesDisponibles = [
    ...new Set(
      materiasProfesor.map(
        (materia) => materia.division
      )
    ),
  ];

  const turnosDisponibles = [
    ...new Set(
      materiasProfesor.map(
        (materia) => materia.turno
      )
    ),
  ];

  // =====================================================
  // FILTRAR MATERIAS DEL PROFESOR
  // =====================================================

  const materiasFiltradas =
    materiasProfesor.filter((materia) => {

      const coincideAnio =
        filtroAnio === "" ||
        String(materia.curso) ===
        String(filtroAnio);

      const coincideDivision =
        filtroDivision === "" ||
        String(materia.division) ===
        String(filtroDivision);

      const coincideTurno =
        filtroTurno === "" ||
        String(materia.turno) ===
        String(filtroTurno);

      return (
        coincideAnio &&
        coincideDivision &&
        coincideTurno
      );
    });

  // =====================================================
  // RETURN
  // =====================================================

  return (
    <div className="app">

      {/* =================================================
          INICIO
      ================================================= */}

      {pantalla === "inicio" && (
        <div className="inicio">

          <div className="inicio-contenedor">

            <header className="inicio-header">
              <h1>ACADIX</h1>
            </header>

            <div className="inicio-contenido">

              <div className="inicio-imagen">
                <img
                  src="/escuela.jpg"
                  alt="Escuela Técnica"
                />
              </div>

              <div className="inicio-info">

                <div className="texto-inicio">

                  <h2>
                    BIENVENIDO A
                    <span>ACADIX</span>
                  </h2>

                  <p>
                    Descubre nuestra plataforma diseñada
                    para potenciar tu éxito. Explora, conecta y
                    gestiona tus productos con facilidad
                  </p>

                </div>

                <div className="inicio-botones">

                  <button
                    className="crear-cuenta"
                    onClick={() => {
                      setMensaje("");
                      setPantalla("registroRoles");
                    }}
                  >
                    CREAR CUENTA
                  </button>

                  <button
                    className="iniciar-sesion"
                    onClick={() =>
                      setPantalla("roles")
                    }
                  >
                    INICIAR SESION
                  </button>

                </div>

              </div>

            </div>

          </div>

        </div>
      )}

      {/* =================================================
          SELECCIÓN DE ROL PARA REGISTRO
      ================================================= */}

      {pantalla === "registroRoles" && (
        <div className="pantalla">

          <div className="contenedor">

            <h1>ACADIX</h1>

            <h2>Crear cuenta</h2>

            <p>
              Seleccioná el tipo de cuenta que querés crear.
            </p>

            <button
              className="boton"
              onClick={() =>
                seleccionarRolRegistro("alumno")
              }
            >
              Crear cuenta de Alumno
            </button>

            <button
              className="boton"
              onClick={() =>
                seleccionarRolRegistro("profesor")
              }
            >
              Crear cuenta de Profesor
            </button>

            <button
              className="boton volver"
              onClick={volverInicio}
            >
              Volver
            </button>

          </div>

        </div>
      )}

      {/* =================================================
          REGISTRO ALUMNO
      ================================================= */}

      {pantalla === "registroAlumno" && (
        <div className="pantalla">

          <div className="contenedor login">

            <h1>ACADIX</h1>

            <h2>Crear cuenta de Alumno</h2>

            <form onSubmit={registrarCuenta}>

              <input
                type="text"
                placeholder="Nombre"
                value={nombreRegistro}
                onChange={(e) =>
                  setNombreRegistro(e.target.value)
                }
                required
              />

              <input
                type="text"
                placeholder="Apellido"
                value={apellidoRegistro}
                onChange={(e) =>
                  setApellidoRegistro(e.target.value)
                }
                required
              />

              <input
                type="email"
                placeholder="Correo electrónico"
                value={emailRegistro}
                onChange={(e) =>
                  setEmailRegistro(e.target.value)
                }
                required
              />

              <input
                type="password"
                placeholder="Contraseña"
                value={passwordRegistro}
                onChange={(e) =>
                  setPasswordRegistro(e.target.value)
                }
                required
              />

              <input
                type="text"
                placeholder="Código de invitación"
                value={codigoRegistro}
                onChange={(e) =>
                  setCodigoRegistro(e.target.value)
                }
                required
              />

              <input
                type="number"
                placeholder="ID del curso"
                value={cursoRegistro}
                onChange={(e) =>
                  setCursoRegistro(e.target.value)
                }
                required
                min="1"
              />

              <button
                className="boton principal"
                type="submit"
                disabled={cargando}
              >
                {cargando
                  ? "Creando cuenta..."
                  : "Crear cuenta"}
              </button>

            </form>

            {mensaje && (
              <p className="mensaje error">
                {mensaje}
              </p>
            )}

            <button
              className="boton volver"
              onClick={() =>
                setPantalla("registroRoles")
              }
            >
              Volver
            </button>

          </div>

        </div>
      )}

      {/* =================================================
          REGISTRO PROFESOR
      ================================================= */}

      {pantalla === "registroProfesor" && (
        <div className="pantalla">

          <div className="contenedor login">

            <h1>ACADIX</h1>

            <h2>Crear cuenta de Profesor</h2>

            <form onSubmit={registrarCuenta}>

              <input
                type="text"
                placeholder="Nombre"
                value={nombreRegistro}
                onChange={(e) =>
                  setNombreRegistro(e.target.value)
                }
                required
              />

              <input
                type="text"
                placeholder="Apellido"
                value={apellidoRegistro}
                onChange={(e) =>
                  setApellidoRegistro(e.target.value)
                }
                required
              />

              <input
                type="email"
                placeholder="Correo electrónico"
                value={emailRegistro}
                onChange={(e) =>
                  setEmailRegistro(e.target.value)
                }
                required
              />

              <input
                type="password"
                placeholder="Contraseña"
                value={passwordRegistro}
                onChange={(e) =>
                  setPasswordRegistro(e.target.value)
                }
                required
              />

              <input
                type="text"
                placeholder="Código de invitación"
                value={codigoRegistro}
                onChange={(e) =>
                  setCodigoRegistro(e.target.value)
                }
                required
              />

              <button
                className="boton principal"
                type="submit"
                disabled={cargando}
              >
                {cargando
                  ? "Creando cuenta..."
                  : "Crear cuenta"}
              </button>

            </form>

            {mensaje && (
              <p className="mensaje error">
                {mensaje}
              </p>
            )}

            <button
              className="boton volver"
              onClick={() =>
                setPantalla("registroRoles")
              }
            >
              Volver
            </button>

          </div>

        </div>
      )}

      {/* =================================================
          SELECCIÓN DE ROL PARA LOGIN
      ================================================= */}

      {pantalla === "roles" && (
        <div className="pantalla">

          <div className="contenedor">

            <h1>ACADIX</h1>

            <h2>Seleccioná tu rol</h2>

            <p>
              Elegí cómo vas a ingresar a la plataforma.
            </p>

            <button
              className="boton"
              onClick={() =>
                seleccionarRol("alumno")
              }
            >
              Alumno
            </button>

            <button
              className="boton"
              onClick={() =>
                seleccionarRol("profesor")
              }
            >
              Profesor
            </button>

            <button
              className="boton"
              onClick={() =>
                seleccionarRol("administrador")
              }
            >
              Administrador
            </button>

            <button
              className="boton volver"
              onClick={volverInicio}
            >
              Volver
            </button>

          </div>

        </div>
      )}

      {/* =================================================
          LOGIN
      ================================================= */}

      {pantalla === "login" && (
        <div className="pantalla">

          <div className="contenedor login">

            <h1>ACADIX</h1>

            <h2>Iniciar sesión</h2>

            <p>
              Rol seleccionado:
              <strong> {rol}</strong>
            </p>

            <form onSubmit={iniciarSesion}>

              <input
                type="email"
                placeholder="Correo electrónico"
                value={email}
                onChange={(e) =>
                  setEmail(e.target.value)
                }
                required
              />

              <input
                type="password"
                placeholder="Contraseña"
                value={password}
                onChange={(e) =>
                  setPassword(e.target.value)
                }
                required
              />

              <button
                className="boton principal"
                type="submit"
                disabled={cargando}
              >
                {cargando
                  ? "Ingresando..."
                  : "Ingresar"}
              </button>

            </form>

            {mensaje && (
              <p
                className={
                  loginCorrecto
                    ? "mensaje correcto"
                    : "mensaje error"
                }
              >
                {mensaje}
              </p>
            )}

            <button
              className="boton volver"
              onClick={() =>
                setPantalla("roles")
              }
            >
              Cambiar rol
            </button>

          </div>

        </div>
      )}

      {
      /* =================================================
          PANEL ALUMNO
      ================================================= */}

      {pantalla === "panelAlumno" && usuario && (
        <div className="pantalla pantalla-alumno">

          <div className="contenedor panel panel-alumno">

            <h1>ACADIX</h1>

            <div className="alumno-lateral">

              <div className="titulo-alumno">
                 PANEL DE ALUMNO
              </div>

              <div className="nombre-alumno">
                {usuario.nombre} {usuario.apellido}
              </div>

              <div className="dato-alumno">
                Año: {usuario.curso || "No disponible"}
              </div>

              <div className="dato-alumno">
                División: {usuario.division || "No disponible"}
              </div>

            </div>
            
            <div className="alumno-contenido">
              {materiaSeleccionada ? (
                <>
                <button
                className="volver-materias"
                onClick={() => setMateriaSeleccionada(null)}
                >
                  ← Volver a mis materias
                  </button>
                  <h2>{materiaSeleccionada.nombre}</h2>
                  <MaterialesPanel
                  token={token}
                  rol="alumno"
                  idCursoMateria={materiaSeleccionada.idCursoMateria}
                  />
                  </>
                  ) : (
                  <>
                  <h2>Mis materias</h2>
                  
                  <div className="materias-alumno">
                    {usuario.materias &&
                    usuario.materias.length > 0 ? (
                      usuario.materias.map((materia, index) => (
                      <button
                      className="materia-alumno"
                      key={materia.idCursoMateria || index}
                      onClick={() => {
                        console.log("MATERIA SELECCIONADA:", materia);
                        setMateriaSeleccionada(
                          typeof materia === "string"
                          ? { nombre: materia }
                          : materia
                        );
                      }}
                      >
                        {typeof materia === "string"
                        ? materia
                        : materia.nombre}
                        </button>
                        ))
                      ) : (
                      <p className="sin-materias">
                        No hay materias asignadas.
                        </p>
                      )}
                      </div>
                      </>
                    )}
                    </div>

            <button
              className="cerrar-alumno"
              onClick={cerrarSesion}
            >
              Cerrar sesión
            </button>

          </div>

        </div>
      )}

      {/* =================================================
          PANEL PROFESOR
      ================================================= */}

      {pantalla === "panelProfesor" && usuario && (
        <div className="pantalla pantalla-profesor">

          <div className="contenedor panel panel-profesor">

            <h1>ACADIX</h1>

            <div className="profesor-lateral">

              <div className="titulo-profesor">
                  PANEL DE PROFESOR
              </div>

              <h3>
                GESTIÓN DE CLASES
              </h3>

              <select
                value={filtroAnio}
                onChange={(e) =>
                  setFiltroAnio(e.target.value)
                }
              >

                <option value="">
                  Año Asignado
                </option>

                {aniosDisponibles.map(
                  (anio, index) => (

                    <option
                      value={anio}
                      key={index}
                    >
                      {anio}
                    </option>

                  )
                )}

              </select>

              <select
                value={filtroDivision}
                onChange={(e) =>
                  setFiltroDivision(e.target.value)
                }
              >

                <option value="">
                  División
                </option>

                {divisionesDisponibles.map(
                  (division, index) => (

                    <option
                      value={division}
                      key={index}
                    >
                      {division}
                    </option>

                  )
                )}

              </select>

              <select
                value={filtroTurno}
                onChange={(e) =>
                  setFiltroTurno(e.target.value)
                }
              >

                <option value="">
                  Turno
                </option>

                {turnosDisponibles.map(
                  (turno, index) => (

                    <option
                      value={turno}
                      key={index}
                    >
                      {turno}
                    </option>

                  )
                )}

              </select>

              <button
                className="limpiar-filtros"
                onClick={() => {
                  setFiltroAnio("");
                  setFiltroDivision("");
                  setFiltroTurno("");
                }}
              >
                Limpiar filtros
              </button>

            </div>

            <div className="materias-profesor">
              {materiaSeleccionada ? (
                <div className="detalle-materia">
                  <button
                  className="volver-materias"
                  onClick={() => setMateriaSeleccionada(null)}
                  >
                    ← Volver a mis materias
                    </button>
                    
                    <h2>{materiaSeleccionada.nombre}</h2>
                    
                    <MaterialesPanel
                    token={token}
                    rol="profesor"
                    idCursoMateria={materiaSeleccionada.idCursoMateria}
                    />
                    </div>
                    ) : (
                      materiasFiltradas.length > 0 ? (
                        materiasFiltradas.map((materia, index) => (
                        <button
                        className="materia-profesor"
                        key={materia.idCursoMateria || index}
                        onClick={() => setMateriaSeleccionada(materia)}
                        >
                          {materia.nombre}
                          </button>
                          ))
                        ) : (
                        <p className="sin-asignaciones">
                          No hay materias para los filtros seleccionados.
                          </p>
                          )
                          )}
                          </div>

            <button
              className="cerrar-profesor"
              onClick={cerrarSesion}
            >
              Cerrar sesión
            </button>

          </div>

        </div>
      )}

      {/* =================================================
        PANEL ADMINISTRADOR
      ================================================= */}

      {pantalla === "panelAdmin" && usuario && (
        <AdminPanel
          usuario={usuario}
          token={token}
          onCerrarSesion={cerrarSesion}
        />
      )}

    </div>
  );
}


export default App;
