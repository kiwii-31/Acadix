import { useState, useCallback, useEffect } from "react";
import api from "../services/api";

// ==========================================
// useCrud
// ==========================================
// Encapsula el patrón repetido de "listar / crear / editar /
// eliminar contra un endpoint" que antes se repetía a mano en
// cada pantalla (cargando, error, recargar después de cada
// acción). Cada Panel.jsx solo se ocupa de renderizar.
//
// Uso:
//   const {
//       items, cargando, error, crear, editar, eliminar, recargar
//   } = useCrud("/api/docentes", token);
// ==========================================

const useCrud = (endpoint, token) => {
    const [items, setItems] = useState([]);
    const [cargando, setCargando] = useState(false);
    const [error, setError] = useState("");

    const recargar = useCallback(async () => {
        setCargando(true);
        setError("");

        try {
            const datos = await api.get(endpoint, token);
            setItems(datos);

        } catch (err) {
            setError(err.message);

        } finally {
            setCargando(false);
        }
    }, [endpoint, token]);

    useEffect(() => {
        recargar();
    }, [recargar]);

    const crear = async (body) => {
        setError("");

        try {
            await api.post(endpoint, body, token);
            await recargar();
            return true;

        } catch (err) {
            setError(err.message);
            return false;
        }
    };

    const editar = async (id, body) => {
        setError("");

        try {
            await api.put(`${endpoint}/${id}`, body, token);
            await recargar();
            return true;

        } catch (err) {
            setError(err.message);
            return false;
        }
    };

    const eliminar = async (id) => {
        setError("");

        try {
            await api.delete(`${endpoint}/${id}`, token);
            await recargar();
            return true;

        } catch (err) {
            setError(err.message);
            return false;
        }
    };

    return { items, cargando, error, crear, editar, eliminar, recargar };
};

export default useCrud;
