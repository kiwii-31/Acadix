// ==========================================
// Cliente API centralizado
// ==========================================
// En vez de repetir "http://localhost:3000" y el manejo de
// errores en cada componente, todo pasa por acá. La URL base
// sale de la variable de entorno VITE_API_URL, y si se le
// pasa un token, se agrega automáticamente en el header
// Authorization.
// ==========================================

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:3000";

class ApiError extends Error {
    constructor(mensaje, status) {
        super(mensaje);
        this.status = status;
    }
}

const request = async (path, { method = "GET", body, token } = {}) => {
    const headers = {
        "Content-Type": "application/json"
    };

    if (token) {
        headers["Authorization"] = `Bearer ${token}`;
    }

    let respuesta;

    try {
        respuesta = await fetch(`${BASE_URL}${path}`, {
            method,
            headers,
            body: body ? JSON.stringify(body) : undefined
        });
    } catch {
        throw new ApiError("No se pudo conectar con el servidor", 0);
    }

    const datos = await respuesta.json().catch(() => ({}));

    if (!respuesta.ok) {
        throw new ApiError(datos.mensaje || "Error en la solicitud", respuesta.status);
    }

    return datos;
};

const api = {
    get: (path, token) => request(path, { method: "GET", token }),
    post: (path, body, token) => request(path, { method: "POST", body, token }),
    put: (path, body, token) => request(path, { method: "PUT", body, token }),
    delete: (path, token) => request(path, { method: "DELETE", token })
};

export default api;
export { ApiError };
