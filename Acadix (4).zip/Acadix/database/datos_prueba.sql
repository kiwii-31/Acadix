USE acadix;

-- ==========================================
-- DATOS DE PRUEBA - ACADIX
-- ==========================================

-- Código de alumno
INSERT INTO codigo (cod, rol, activo)
SELECT 'ALUMNO123', 'alumno', 1
WHERE NOT EXISTS (
    SELECT 1
    FROM codigo
    WHERE cod = 'ALUMNO123'
);

-- Código de profesor
INSERT INTO codigo (cod, rol, activo)
SELECT 'PROFESOR123', 'profesor', 1
WHERE NOT EXISTS (
    SELECT 1
    FROM codigo
    WHERE cod = 'PROFESOR123'
);

-- Usuario alumno
INSERT INTO usuario
(nombre, apellido, email, contraseña, cod_invitacion)
SELECT
'Prueba',
'Alumno',
'prueba@gmail.com',
'123456',
id_codigo
FROM codigo
WHERE cod = 'ALUMNO123'
AND NOT EXISTS (
    SELECT 1
    FROM usuario
    WHERE email = 'prueba@gmail.com'
);

-- Usuario profesor
INSERT INTO usuario
(nombre, apellido, email, contraseña, cod_invitacion)
SELECT
'Juan',
'Profesor',
'profesor@gmail.com',
'Profesor123',
id_codigo
FROM codigo
WHERE cod = 'PROFESOR123'
AND NOT EXISTS (
    SELECT 1
    FROM usuario
    WHERE email = 'profesor@gmail.com'
);

-- Relacionar profesor con docente
INSERT INTO docente (idusuario)
SELECT u.id_user
FROM usuario u
WHERE u.email = 'profesor@gmail.com'
AND NOT EXISTS (
    SELECT 1
    FROM docente d
    WHERE d.idusuario = u.id_user
);


-- ==========================================
-- CONTINUACION DE DATOS DE PRUEBA - ACADIX
-- ==========================================

USE acadix;

-- 1. Crear el usuario administrador
INSERT INTO usuario (nombre, apellido, email, contraseña)
SELECT 'Administrador', 'Acadix', 'admin@acadix.com', 'acadix1234'
WHERE NOT EXISTS (
    SELECT 1
    FROM usuario
    WHERE email = 'admin@acadix.com'
);

-- 2. Vincular el usuario con la tabla admin
INSERT INTO admin (User_ID)
SELECT u.id_user
FROM usuario u
WHERE u.email = 'admin@acadix.com'
AND NOT EXISTS (
    SELECT 1
    FROM admin a
    WHERE a.User_ID = u.id_user
);

-- 3. Comprobar que se creó correctamente
SELECT
    u.id_user,
    u.nombre,
    u.apellido,
    u.email,
    a.id_admin
FROM usuario u
INNER JOIN admin a ON a.User_ID = u.id_user
WHERE u.email = 'admin@acadix.com';

/* OTROS  */
-- 1. Crear un segundo alumno
INSERT INTO codigo (cod, rol, activo)
SELECT 'ALUMNO456', 'alumno', 1
WHERE NOT EXISTS (
    SELECT 1 FROM codigo WHERE cod = 'ALUMNO456'
);

INSERT INTO usuario
(nombre, apellido, email, contraseña, cod_invitacion)
SELECT 'Maria', 'Gonzalez', 'maria@gmail.com', 'Maria456',
       c.id_codigo
FROM codigo c
WHERE c.cod = 'ALUMNO456'
AND NOT EXISTS (
    SELECT 1 FROM usuario WHERE email = 'maria@gmail.com'
);

-- 2. Crear un segundo profesor
INSERT INTO codigo (cod, rol, activo)
SELECT 'PROFESOR456', 'profesor', 1
WHERE NOT EXISTS (
    SELECT 1 FROM codigo WHERE cod = 'PROFESOR456'
);

INSERT INTO usuario
(nombre, apellido, email, contraseña, cod_invitacion)
SELECT 'Laura', 'Martinez', 'laura@gmail.com', 'Laura456',
       c.id_codigo
FROM codigo c
WHERE c.cod = 'PROFESOR456'
AND NOT EXISTS (
    SELECT 1 FROM usuario WHERE email = 'laura@gmail.com'
);

INSERT INTO docente (idusuario)
SELECT u.id_user
FROM usuario u
WHERE u.email = 'laura@gmail.com'
AND NOT EXISTS (
    SELECT 1 FROM docente d WHERE d.idusuario = u.id_user
);

-- 3. Crear año escolar
INSERT INTO anio (anio)
SELECT '2026'
WHERE NOT EXISTS (
    SELECT 1 FROM anio WHERE anio = '2026'
);

-- 4. Crear división
INSERT INTO division (nombre)
SELECT 'A'
WHERE NOT EXISTS (
    SELECT 1 FROM division WHERE nombre = 'A'
);

-- 5. Crear turno mañana
INSERT INTO turno (nombre)
SELECT 'Mañana'
WHERE NOT EXISTS (
    SELECT 1 FROM turno WHERE nombre = 'Mañana'
);

-- 6. Crear especialidad
INSERT INTO especialidad (nombre)
SELECT 'Informatica'
WHERE NOT EXISTS (
    SELECT 1 FROM especialidad WHERE nombre = 'Informatica'
);

-- 7. Relacionar turno con especialidad
INSERT INTO turnoxespe (ID_turno, ID_espe)
SELECT t.id_turno, e.id_espe
FROM turno t
CROSS JOIN especialidad e
WHERE t.nombre = 'Mañana'
AND e.nombre = 'Informatica'
AND NOT EXISTS (
    SELECT 1
    FROM turnoxespe te
    WHERE te.ID_turno = t.id_turno
      AND te.ID_espe = e.id_espe
);

-- 8. Crear curso: 6to A
INSERT INTO curso (IDanio, IDdiv, IDTXE)
SELECT a.id_anio, d.id_div, te.id_TxE
FROM anio a
CROSS JOIN division d
CROSS JOIN turnoxespe te
JOIN turno t ON t.id_turno = te.ID_turno
JOIN especialidad e ON e.id_espe = te.ID_espe
WHERE a.anio = '2026'
AND d.nombre = 'A'
AND t.nombre = 'Mañana'
AND e.nombre = 'Informatica'
AND NOT EXISTS (
    SELECT 1
    FROM curso c
    WHERE c.IDanio = a.id_anio
      AND c.IDdiv = d.id_div
      AND c.IDTXE = te.id_TxE
);

-- 9. Crear materias
INSERT INTO materia (nombre)
SELECT 'Programacion'
WHERE NOT EXISTS (
    SELECT 1 FROM materia WHERE nombre = 'Programacion'
);

INSERT INTO materia (nombre)
SELECT 'Base de Datos'
WHERE NOT EXISTS (
    SELECT 1 FROM materia WHERE nombre = 'Base de Datos'
);

INSERT INTO materia (nombre)
SELECT 'Redes'
WHERE NOT EXISTS (
    SELECT 1 FROM materia WHERE nombre = 'Redes'
);

INSERT INTO materia (nombre)
SELECT 'Diseno Grafico'
WHERE NOT EXISTS (
    SELECT 1 FROM materia WHERE nombre = 'Diseno Grafico'
);

-- 10. Relacionar las materias con el curso
INSERT INTO cursomateria (curso_ID, materia_ID)
SELECT c.id_curso, m.id_materia
FROM curso c
JOIN anio a ON a.id_anio = c.IDanio
JOIN division d ON d.id_div = c.IDdiv
JOIN turnoxespe te ON te.id_TxE = c.IDTXE
JOIN especialidad e ON e.id_espe = te.ID_espe
CROSS JOIN materia m
WHERE a.anio = '2026'
AND d.nombre = 'A'
AND e.nombre = 'Informatica'
AND m.nombre IN (
    'Programacion', 'Base de Datos',
    'Redes', 'Diseno Grafico'
)
AND NOT EXISTS (
    SELECT 1
    FROM cursomateria cm
    WHERE cm.curso_ID = c.id_curso
      AND cm.materia_ID = m.id_materia
);

-- 11. Crear bimestres
INSERT INTO bimestre (num)
SELECT 'Primer bimestre'
WHERE NOT EXISTS (
    SELECT 1 FROM bimestre WHERE num = 'Primer bimestre'
);

INSERT INTO bimestre (num)
SELECT 'Segundo bimestre'
WHERE NOT EXISTS (
    SELECT 1 FROM bimestre WHERE num = 'Segundo bimestre'
);

INSERT INTO bimestre (num)
SELECT 'Tercer bimestre'
WHERE NOT EXISTS (
    SELECT 1 FROM bimestre WHERE num = 'Tercer bimestre'
);

INSERT INTO bimestre (num)
SELECT 'Cuarto bimestre'
WHERE NOT EXISTS (
    SELECT 1 FROM bimestre WHERE num = 'Cuarto bimestre'
);

-- 12. Asignar materias a los profesores
INSERT INTO asigdocente (profe_id, id_cursoMat)
SELECT d.id_docente, cm.id_CxM
FROM docente d
JOIN usuario u ON u.id_user = d.idusuario
JOIN cursomateria cm ON 1 = 1
JOIN curso c ON c.id_curso = cm.curso_ID
JOIN anio a ON a.id_anio = c.IDanio
JOIN division dv ON dv.id_div = c.IDdiv
JOIN turnoxespe te ON te.id_TxE = c.IDTXE
JOIN especialidad e ON e.id_espe = te.ID_espe
JOIN materia m ON m.id_materia = cm.materia_ID
WHERE u.email = 'profesor@gmail.com'
AND a.anio = '2026'
AND dv.nombre = 'A'
AND e.nombre = 'Informatica'
AND m.nombre IN ('Programacion', 'Base de Datos')
AND NOT EXISTS (
    SELECT 1
    FROM asigdocente ad
    WHERE ad.profe_id = d.id_docente
      AND ad.id_cursoMat = cm.id_CxM
);

INSERT INTO asigdocente (profe_id, id_cursoMat)
SELECT d.id_docente, cm.id_CxM
FROM docente d
JOIN usuario u ON u.id_user = d.idusuario
JOIN cursomateria cm ON 1 = 1
JOIN curso c ON c.id_curso = cm.curso_ID
JOIN anio a ON a.id_anio = c.IDanio
JOIN division dv ON dv.id_div = c.IDdiv
JOIN turnoxespe te ON te.id_TxE = c.IDTXE
JOIN especialidad e ON e.id_espe = te.ID_espe
JOIN materia m ON m.id_materia = cm.materia_ID
WHERE u.email = 'laura@gmail.com'
AND a.anio = '2026'
AND dv.nombre = 'A'
AND e.nombre = 'Informatica'
AND m.nombre IN ('Redes', 'Diseno Grafico')
AND NOT EXISTS (
    SELECT 1
    FROM asigdocente ad
    WHERE ad.profe_id = d.id_docente
      AND ad.id_cursoMat = cm.id_CxM
);

-- 13. Crear temarios de ejemplo
INSERT INTO temario
(titulo, descripcion, idCursoMateria, idBimestre)
SELECT
    'Introduccion a la programacion',
    'Conceptos basicos, algoritmos y variables.',
    cm.id_CxM,
    b.id_bime
FROM cursomateria cm
JOIN materia m ON m.id_materia = cm.materia_ID
JOIN curso c ON c.id_curso = cm.curso_ID
JOIN anio a ON a.id_anio = c.IDanio
JOIN division d ON d.id_div = c.IDdiv
JOIN bimestre b ON b.num = 'Primer bimestre'
WHERE m.nombre = 'Programacion'
AND a.anio = '2026'
AND d.nombre = 'A'
AND NOT EXISTS (
    SELECT 1
    FROM temario t
    WHERE t.titulo = 'Introduccion a la programacion'
      AND t.idCursoMateria = cm.id_CxM
      AND t.idBimestre = b.id_bime
);

INSERT INTO temario
(titulo, descripcion, idCursoMateria, idBimestre)
SELECT
    'Consultas SQL',
    'Consultas SELECT, filtros y ordenamiento.',
    cm.id_CxM,
    b.id_bime
FROM cursomateria cm
JOIN materia m ON m.id_materia = cm.materia_ID
JOIN curso c ON c.id_curso = cm.curso_ID
JOIN anio a ON a.id_anio = c.IDanio
JOIN division d ON d.id_div = c.IDdiv
JOIN bimestre b ON b.num = 'Primer bimestre'
WHERE m.nombre = 'Base de Datos'
AND a.anio = '2026'
AND d.nombre = 'A'
AND NOT EXISTS (
    SELECT 1
    FROM temario t
    WHERE t.titulo = 'Consultas SQL'
      AND t.idCursoMateria = cm.id_CxM
      AND t.idBimestre = b.id_bime
);

INSERT INTO temario
(titulo, descripcion, idCursoMateria, idBimestre)
SELECT
    'Fundamentos de redes',
    'Direccionamiento IP y redes locales.',
    cm.id_CxM,
    b.id_bime
FROM cursomateria cm
JOIN materia m ON m.id_materia = cm.materia_ID
JOIN curso c ON c.id_curso = cm.curso_ID
JOIN anio a ON a.id_anio = c.IDanio
JOIN division d ON d.id_div = c.IDdiv
JOIN bimestre b ON b.num = 'Primer bimestre'
WHERE m.nombre = 'Redes'
AND a.anio = '2026'
AND d.nombre = 'A'
AND NOT EXISTS (
    SELECT 1
    FROM temario t
    WHERE t.titulo = 'Fundamentos de redes'
      AND t.idCursoMateria = cm.id_CxM
      AND t.idBimestre = b.id_bime
);

-- 14. Agregar materiales a los temarios
INSERT INTO material (titulo, descripcion, archivo, idTemario)
SELECT
    'Guia de algoritmos',
    'Ejercicios introductorios',
    'guia_algoritmos.pdf',
    t.id_temario
FROM temario t
WHERE t.titulo = 'Introduccion a la programacion'
AND NOT EXISTS (
    SELECT 1 FROM material m
    WHERE m.idTemario = t.id_temario
      AND m.titulo = 'Guia de algoritmos'
);

INSERT INTO material (titulo, descripcion, archivo, idTemario)
SELECT
    'Practica de SQL',
    'Ejercicios de consultas',
    'practica_sql.pdf',
    t.id_temario
FROM temario t
WHERE t.titulo = 'Consultas SQL'
AND NOT EXISTS (
    SELECT 1 FROM material m
    WHERE m.idTemario = t.id_temario
      AND m.titulo = 'Practica de SQL'
);

INSERT INTO material (titulo, descripcion, archivo, idTemario)
SELECT
    'Guia de direccionamiento',
    'Practica de redes IP',
    'guia_redes.pdf',
    t.id_temario
FROM temario t
WHERE t.titulo = 'Fundamentos de redes'
AND NOT EXISTS (
    SELECT 1 FROM material m
    WHERE m.idTemario = t.id_temario
      AND m.titulo = 'Guia de direccionamiento'
);

-- 15. Relacionar los alumnos con el curso
INSERT INTO alumno (iduser, idcurso)
SELECT u.id_user, c.id_curso
FROM usuario u
JOIN codigo co ON co.id_codigo = u.cod_invitacion
JOIN curso c ON 1 = 1
JOIN anio a ON a.id_anio = c.IDanio
JOIN division d ON d.id_div = c.IDdiv
JOIN turnoxespe te ON te.id_TxE = c.IDTXE
JOIN especialidad e ON e.id_espe = te.ID_espe
WHERE u.email IN ('prueba@gmail.com', 'maria@gmail.com')
AND co.rol = 'alumno'
AND a.anio = '2026'
AND d.nombre = 'A'
AND e.nombre = 'Informatica'
AND NOT EXISTS (
    SELECT 1
    FROM alumno al
    WHERE al.iduser = u.id_user
      AND al.idcurso = c.id_curso
);

-- ==========================================
-- FIN DE DATOS DE PRUEBA
-- ==========================================
/* 

-- Consultar usuarios
SELECT id_user, nombre, apellido, email
FROM usuario;

-- Consultar cursos
SELECT c.id_curso, a.anio, d.nombre AS division,
       t.nombre AS turno, e.nombre AS especialidad
FROM curso c
JOIN anio a ON a.id_anio = c.IDanio
JOIN division d ON d.id_div = c.IDdiv
JOIN turnoxespe te ON te.id_TxE = c.IDTXE
JOIN turno t ON t.id_turno = te.ID_turno
JOIN especialidad e ON e.id_espe = te.ID_espe;

-- Consultar temarios y materiales
SELECT m.nombre AS materia, t.titulo AS temario,
       ma.titulo AS material, ma.archivo
FROM material ma
JOIN temario t ON t.id_temario = ma.idTemario
JOIN cursomateria cm ON cm.id_CxM = t.idCursoMateria
JOIN materia m ON m.id_materia = cm.materia_ID;

/*