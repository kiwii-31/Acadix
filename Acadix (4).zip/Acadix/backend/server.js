const express = require("express");
const cors = require("cors");
const conexion = require("./config/db");
const authRoutes = require("./routes/auth.routes");
const alumnoRoutes = require("./routes/alumno.routes");
const docenteRoutes = require("./routes/docente.routes");
const materiaRoutes = require("./routes/materia.routes");
const cursoRoutes = require("./routes/curso.routes");
const catalogoRoutes = require("./routes/catalogo.routes");

const temarioPluginRoutes = require("./plugins/materiales/routes/temario.routes");
const materialPluginRoutes = require("./plugins/materiales/routes/material.routes");

const app = express();

app.use(cors());
app.use(express.json());
app.use("/api/auth", authRoutes);
app.use("/api/alumnos", alumnoRoutes);
app.use("/api/docentes", docenteRoutes);
app.use("/api/materias", materiaRoutes);
app.use("/api/cursos", cursoRoutes);
app.use("/api/catalogos", catalogoRoutes);

app.use("/api/plugin-materiales/temarios", temarioPluginRoutes);
app.use("/api/plugin-materiales/materiales", materialPluginRoutes);

// Ruta principal
app.get("/", (req, res) => {
    res.json({
        mensaje: "Servidor de Acadix funcionando correctamente"
    });
});

// Ruta para probar la conexión con MySQL
app.get("/api/test-db", async (req, res) => {
    try {
        const [resultado] = await conexion.query("SELECT 1 AS conectado");

        res.json({
            mensaje: "Conexión con MySQL funcionando",
            resultado: resultado
        });

    } catch (error) {
    console.error("ERROR COMPLETO DE MYSQL:", error);

    res.status(500).json({
        mensaje: "Error al conectar con MySQL",
        error: error.message,
        codigo: error.code,
        detalle: error
        });
    } 
});

// Iniciar servidor
const PORT = 3000;

app.listen(PORT, () => {
    console.log(`Servidor de Acadix ejecutándose en http://localhost:${PORT}`);
});