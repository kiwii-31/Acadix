const multer = require("multer");

const almacenamiento = multer.memoryStorage();

const subirPDF = multer({
    storage: almacenamiento,
    limits: {
        fileSize: 10 * 1024 * 1024 // Máximo 10 MB
    },
    fileFilter: (req, archivo, callback) => {
        if (archivo.mimetype !== "application/pdf") {
            return callback(
                new Error("Solo se permiten archivos PDF")
            );
        }

        callback(null, true);
    }
});

module.exports = subirPDF;
