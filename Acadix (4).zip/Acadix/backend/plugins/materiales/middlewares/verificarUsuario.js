const jwt = require("jsonwebtoken");

const verificarUsuario = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({
            mensaje: "Tenés que iniciar sesión para realizar esta acción"
        });
    }

    const token = authHeader.split(" ")[1];

    try {
        const usuario = jwt.verify(token, process.env.JWT_SECRET);

        req.usuario = usuario;
        next();
    } catch (error) {
        return res.status(401).json({
            mensaje: "El token es inválido o expiró"
        });
    }
};

module.exports = verificarUsuario;
