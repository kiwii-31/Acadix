const express = require("express");
const router = express.Router();

const verificarUsuario = require("../middlewares/verificarUsuario");
const subirPDF = require("../middlewares/subirPDF");

const {
    crearMaterial,
    obtenerMateriales,
    descargarMaterial,
    editarMaterial,
    eliminarMaterial
} = require("../controllers/material.controller");

router.use(verificarUsuario);

router.get("/temarios/:idTemario", obtenerMateriales);

router.post(
    "/temarios/:idTemario",
    (req, res, next) => {
        subirPDF.single("archivo")(req, res, (error) => {
            if (error) {
                return res.status(400).json({
                    mensaje: error.message
                });
            }

            next();
        });
    },
    crearMaterial
);

router.get("/:id/archivo", descargarMaterial);
router.put("/:id", editarMaterial);
router.delete("/:id", eliminarMaterial);

module.exports = router;
