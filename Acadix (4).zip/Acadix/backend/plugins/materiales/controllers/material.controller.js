const conexion = require("../../../config/db");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const carpetaPDF = path.join(__dirname, "../uploads/materiales");

async function verificarAccesoTemario(req, idTemario) {
    const { id_user, rol } = req.usuario;

    if (rol.toLowerCase() === "profesor") {
        const [filas] = await conexion.query(
            `SELECT t.id_temario
             FROM temario t
             INNER JOIN cursomateria cm
                ON t.idCursoMateria = cm.id_CxM
             INNER JOIN asigdocente ad
                ON ad.id_cursoMat = cm.id_CxM
             INNER JOIN docente d
                ON d.id_docente = ad.profe_id
             WHERE t.id_temario = ?
               AND d.idusuario = ?`,
            [idTemario, id_user]
        );

        return filas.length > 0;
    }

    if (rol.toLowerCase() === "alumno") {
        const [filas] = await conexion.query(
            `SELECT t.id_temario
             FROM temario t
             INNER JOIN cursomateria cm
                ON t.idCursoMateria = cm.id_CxM
             INNER JOIN alumno a
                ON a.idcurso = cm.curso_ID
             WHERE t.id_temario = ?
               AND a.iduser = ?`,
            [idTemario, id_user]
        );

        return filas.length > 0;
    }

    return false;
}

async function obtenerMaterialPropio(idMaterial, idUsuario) {
    const [filas] = await conexion.query(
        `SELECT m.*
         FROM material m
         INNER JOIN temario t
            ON m.idTemario = t.id_temario
         INNER JOIN cursomateria cm
            ON t.idCursoMateria = cm.id_CxM
         INNER JOIN asigdocente ad
            ON ad.id_cursoMat = cm.id_CxM
         INNER JOIN docente d
            ON d.id_docente = ad.profe_id
         WHERE m.id_material = ?
           AND d.idusuario = ?`,
        [idMaterial, idUsuario]
    );

    return filas[0] || null;
}

// PUBLICAR MATERIAL PDF
const crearMaterial = async (req, res) => {
    let rutaGuardada = null;

    try {
        const { id_user, rol } = req.usuario;
        const { idTemario } = req.params;
        const { titulo, descripcion } = req.body;

        if (rol.toLowerCase() !== "profesor") {
            return res.status(403).json({
                mensaje: "Solo los profesores pueden publicar materiales"
            });
        }

        if (!titulo || !titulo.trim()) {
            return res.status(400).json({
                mensaje: "El título es obligatorio"
            });
        }

        if (!req.file) {
            return res.status(400).json({
                mensaje: "Tenés que seleccionar un archivo PDF"
            });
        }

        const tieneAcceso = await verificarAccesoTemario(
            req,
            idTemario
        );

        if (!tieneAcceso) {
            return res.status(403).json({
                mensaje: "No tenés permiso para publicar en este temario"
            });
        }

        // Comprueba que el archivo realmente tenga formato PDF.
        const firmaPDF = req.file.buffer
            .subarray(0, 5)
            .toString();

        if (firmaPDF !== "%PDF-") {
            return res.status(400).json({
                mensaje: "El archivo seleccionado no es un PDF válido"
            });
        }

        if (!fs.existsSync(carpetaPDF)) {
            fs.mkdirSync(carpetaPDF, { recursive: true });
        }

        const nombreArchivo = `${crypto.randomUUID()}.pdf`;
        
        const rutaAbsoluta = path.join(
            carpetaPDF,
            nombreArchivo
        );

        rutaGuardada = path.join(
            "plugins",
            "materiales",
            "uploads",
            "materiales",
            nombreArchivo
        );

        fs.writeFileSync(rutaAbsoluta, req.file.buffer);

        const [resultado] = await conexion.query(
            `INSERT INTO material
                (titulo, descripcion, archivo, idTemario)
             VALUES (?, ?, ?, ?)`,
            [
                titulo.trim(),
                descripcion || null,
                rutaGuardada,
                idTemario
            ]
        );

        res.status(201).json({
            mensaje: "Material publicado correctamente",
            material: {
                id_material: resultado.insertId,
                titulo: titulo.trim(),
                descripcion: descripcion || null,
                archivo: rutaGuardada,
                idTemario
            }
        });

    } catch (error) {
        if (rutaGuardada) {
            const archivo = path.resolve(
                __dirname,
                "../../../",
                rutaGuardada
            );

            if (fs.existsSync(archivo)) {
                fs.unlinkSync(archivo);
            }
        }

        console.error("Error al publicar material:", error);

        res.status(500).json({
            mensaje: "No se pudo publicar el material"
        });
    }
};

// CONSULTAR MATERIALES DE UN TEMARIO
const obtenerMateriales = async (req, res) => {
    try {
        const { idTemario } = req.params;

        const tieneAcceso = await verificarAccesoTemario(
            req,
            idTemario
        );

        if (!tieneAcceso) {
            return res.status(403).json({
                mensaje: "No tenés permiso para consultar este temario"
            });
        }

        const [materiales] = await conexion.query(
            `SELECT
                id_material,
                titulo,
                descripcion,
                idTemario
             FROM material
             WHERE idTemario = ?
             ORDER BY id_material DESC`,
            [idTemario]
        );

        res.json(materiales);

    } catch (error) {
        console.error("Error al consultar materiales:", error);

        res.status(500).json({
            mensaje: "No se pudieron obtener los materiales"
        });
    }
};

// DESCARGAR O VISUALIZAR PDF
const descargarMaterial = async (req, res) => {
    try {
        const { id } = req.params;
        const { id_user, rol } = req.usuario;

        const [filas] = await conexion.query(
            `SELECT m.*
             FROM material m
             WHERE m.id_material = ?`,
            [id]
        );

        if (filas.length === 0) {
            return res.status(404).json({
                mensaje: "Material no encontrado"
            });
        }

        const material = filas[0];

        const tieneAcceso = await verificarAccesoTemario(
            req,
            material.idTemario
        );

        if (!tieneAcceso) {
            return res.status(403).json({
                mensaje: "No tenés permiso para acceder a este archivo"
            });
        }

        const nombreArchivo = path.basename(
            material.archivo.replace(/\\/g, "/")
        );
        const rutaAbsoluta = path.join(
            carpetaPDF,
            nombreArchivo
        );

        console.log("Ruta guardada en MySQL:", material.archivo);
        console.log("Carpeta de PDFs:", carpetaPDF);
        console.log("Ruta completa que busca:", rutaAbsoluta);
        console.log("¿Existe el archivo?:", fs.existsSync(rutaAbsoluta));

        if (!fs.existsSync(rutaAbsoluta)) {
            return res.status(404).json({
                mensaje: "El archivo PDF no se encuentra en el servidor"
            });
        }

        res.type("application/pdf");
        res.sendFile(rutaAbsoluta);

    } catch (error) {
        console.error("Error al descargar PDF:", error);

        res.status(500).json({
            mensaje: "No se pudo descargar el archivo"
        });
    }
};

// MODIFICAR TÍTULO Y DESCRIPCIÓN
const editarMaterial = async (req, res) => {
    try {
        const { id_user, rol } = req.usuario;
        const { id } = req.params;
        const { titulo, descripcion } = req.body;

        if (rol.toLowerCase() !== "profesor") {
            return res.status(403).json({
                mensaje: "Solo los profesores pueden modificar materiales"
            });
        }

        if (!titulo || !titulo.trim()) {
            return res.status(400).json({
                mensaje: "El título es obligatorio"
            });
        }

        const material = await obtenerMaterialPropio(id, id_user);

        if (!material) {
            return res.status(404).json({
                mensaje: "Material no encontrado o sin permisos"
            });
        }

        await conexion.query(
            `UPDATE material
             SET titulo = ?, descripcion = ?
             WHERE id_material = ?`,
            [titulo.trim(), descripcion || null, id]
        );

        res.json({
            mensaje: "Material actualizado correctamente"
        });

    } catch (error) {
        console.error("Error al editar material:", error);

        res.status(500).json({
            mensaje: "No se pudo modificar el material"
        });
    }
};

// ELIMINAR MATERIAL
const eliminarMaterial = async (req, res) => {
    try {
        const { id_user, rol } = req.usuario;
        const { id } = req.params;

        if (rol.toLowerCase() !== "profesor") {
            return res.status(403).json({
                mensaje: "Solo los profesores pueden eliminar materiales"
            });
        }

        const material = await obtenerMaterialPropio(id, id_user);

        if (!material) {
            return res.status(404).json({
                mensaje: "Material no encontrado o sin permisos"
            });
        }

        await conexion.query(
            "DELETE FROM material WHERE id_material = ?",
            [id]
        );

        const nombreArchivo = path.basename(
            material.archivo.replace(/\\/g, "/")
        );

        const rutaAbsoluta = path.join(
            carpetaPDF,
            nombreArchivo
        );

        if (fs.existsSync(rutaAbsoluta)) {
            fs.unlinkSync(rutaAbsoluta);
        }

        res.json({
            mensaje: "Material eliminado correctamente"
        });

    } catch (error) {
        console.error("Error al eliminar material:", error);

        res.status(500).json({
            mensaje: "No se pudo eliminar el material"
        });
    }
};

module.exports = {
    crearMaterial,
    obtenerMateriales,
    descargarMaterial,
    editarMaterial,
    eliminarMaterial
};
