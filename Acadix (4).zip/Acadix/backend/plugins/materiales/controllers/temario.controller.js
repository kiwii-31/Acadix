const conexion = require("../../../config/db");

// Comprueba que el profesor tenga asignada la materia.
async function profesorTieneMateria(idUsuario, idCursoMateria) {
    const [filas] = await conexion.query(
        `SELECT ad.id_asignacion
         FROM docente d
         INNER JOIN asigdocente ad ON ad.profe_id = d.id_docente
         WHERE d.idusuario = ? AND ad.id_cursoMat = ?`,
        [idUsuario, idCursoMateria]
    );

    return filas.length > 0;
}

// CONSULTAR TEMARIOS
const obtenerTemarios = async (req, res) => {
    try {
        const { id_user, rol } = req.usuario;

        let consulta;
        let parametros;

        if (rol.toLowerCase() === "profesor") {
            consulta = `
                SELECT
                    t.id_temario,
                    t.titulo,
                    t.descripcion,
                    t.idCursoMateria,
                    t.idBimestre,
                    b.num AS bimestre,
                    m.nombre AS materia,
                    c.id_curso AS idCurso
                FROM temario t
                INNER JOIN cursomateria cm
                    ON t.idCursoMateria = cm.id_CxM
                INNER JOIN materia m
                    ON cm.materia_ID = m.id_materia
                INNER JOIN curso c
                    ON cm.curso_ID = c.id_curso
                LEFT JOIN bimestre b
                    ON t.idBimestre = b.id_bime
                INNER JOIN asigdocente ad
                    ON ad.id_cursoMat = cm.id_CxM
                INNER JOIN docente d
                    ON d.id_docente = ad.profe_id
                WHERE d.idusuario = ?
                ORDER BY m.nombre, t.idBimestre, t.titulo
            `;
            parametros = [id_user];

        } else if (rol.toLowerCase() === "alumno") {
            consulta = `
                SELECT
                    t.id_temario,
                    t.titulo,
                    t.descripcion,
                    t.idCursoMateria,
                    t.idBimestre,
                    b.num AS bimestre,
                    m.nombre AS materia,
                    c.id_curso AS idCurso
                FROM temario t
                INNER JOIN cursomateria cm
                    ON t.idCursoMateria = cm.id_CxM
                INNER JOIN materia m
                    ON cm.materia_ID = m.id_materia
                INNER JOIN curso c
                    ON cm.curso_ID = c.id_curso
                LEFT JOIN bimestre b
                    ON t.idBimestre = b.id_bime
                INNER JOIN alumno a
                    ON a.idcurso = c.id_curso
                WHERE a.iduser = ?
                ORDER BY m.nombre, t.idBimestre, t.titulo
            `;
            parametros = [id_user];

        } else {
            return res.status(403).json({
                mensaje: "Tu rol no tiene permiso para consultar temarios"
            });
        }

        const [temarios] = await conexion.query(consulta, parametros);
        res.json(temarios);

    } catch (error) {
        console.error("Error al obtener temarios:", error);
        res.status(500).json({
            mensaje: "No se pudieron obtener los temarios"
        });
    }
};

// CREAR TEMARIO
const crearTemario = async (req, res) => {
    try {
        const { id_user, rol } = req.usuario;
        const { titulo, descripcion, idCursoMateria, idBimestre } = req.body;

        if (rol.toLowerCase() !== "profesor") {
            return res.status(403).json({
                mensaje: "Solo los profesores pueden crear temarios"
            });
        }

        if (!titulo || !titulo.trim() || !idCursoMateria || !idBimestre) {
            return res.status(400).json({
                mensaje: "El título, la materia y el bimestre son obligatorios"
            });
        }

        const tieneMateria = await profesorTieneMateria(
            id_user,
            idCursoMateria
        );

        if (!tieneMateria) {
            return res.status(403).json({
                mensaje: "No tenés asignada esa materia"
            });
        }

        const [bimestres] = await conexion.query(
            "SELECT id_bime FROM bimestre WHERE id_bime = ?",
            [idBimestre]
        );

        if (bimestres.length === 0) {
            return res.status(400).json({
                mensaje: "El bimestre seleccionado no existe"
            });
        }

        const [resultado] = await conexion.query(
            `INSERT INTO temario
                (titulo, descripcion, idCursoMateria, idBimestre)
             VALUES (?, ?, ?, ?)`,
            [
                titulo.trim(),
                descripcion || null,
                idCursoMateria,
                idBimestre
            ]
        );

        res.status(201).json({
            mensaje: "Temario creado correctamente",
            id_temario: resultado.insertId
        });

    } catch (error) {
        console.error("Error al crear temario:", error);
        res.status(500).json({
            mensaje: "No se pudo crear el temario"
        });
    }
};

// MODIFICAR TEMARIO
const editarTemario = async (req, res) => {
    try {
        const { id_user, rol } = req.usuario;
        const { id } = req.params;
        const { titulo, descripcion, idBimestre } = req.body;

        if (rol.toLowerCase() !== "profesor") {
            return res.status(403).json({
                mensaje: "Solo los profesores pueden modificar temarios"
            });
        }

        if (!titulo || !titulo.trim() || !idBimestre) {
            return res.status(400).json({
                mensaje: "El título y el bimestre son obligatorios"
            });
        }

        const [temarios] = await conexion.query(
            `SELECT t.id_temario, t.idCursoMateria
             FROM temario t
             INNER JOIN cursomateria cm
                ON t.idCursoMateria = cm.id_CxM
             INNER JOIN asigdocente ad
                ON ad.id_cursoMat = cm.id_CxM
             INNER JOIN docente d
                ON d.id_docente = ad.profe_id
             WHERE t.id_temario = ? AND d.idusuario = ?`,
            [id, id_user]
        );

        if (temarios.length === 0) {
            return res.status(404).json({
                mensaje: "Temario no encontrado o no tenés permiso para modificarlo"
            });
        }

        const [bimestres] = await conexion.query(
            "SELECT id_bime FROM bimestre WHERE id_bime = ?",
            [idBimestre]
        );

        if (bimestres.length === 0) {
            return res.status(400).json({
                mensaje: "El bimestre seleccionado no existe"
            });
        }

        await conexion.query(
            `UPDATE temario
             SET titulo = ?, descripcion = ?, idBimestre = ?
             WHERE id_temario = ?`,
            [titulo.trim(), descripcion || null, idBimestre, id]
        );

        res.json({
            mensaje: "Temario actualizado correctamente"
        });

    } catch (error) {
        console.error("Error al editar temario:", error);
        res.status(500).json({
            mensaje: "No se pudo modificar el temario"
        });
    }
};

// ELIMINAR TEMARIO
const eliminarTemario = async (req, res) => {
    try {
        const { id_user, rol } = req.usuario;
        const { id } = req.params;

        if (rol.toLowerCase() !== "profesor") {
            return res.status(403).json({
                mensaje: "Solo los profesores pueden eliminar temarios"
            });
        }

        const [temarios] = await conexion.query(
            `SELECT t.id_temario
             FROM temario t
             INNER JOIN cursomateria cm
                ON t.idCursoMateria = cm.id_CxM
             INNER JOIN asigdocente ad
                ON ad.id_cursoMat = cm.id_CxM
             INNER JOIN docente d
                ON d.id_docente = ad.profe_id
             WHERE t.id_temario = ? AND d.idusuario = ?`,
            [id, id_user]
        );

        if (temarios.length === 0) {
            return res.status(404).json({
                mensaje: "Temario no encontrado o no tenés permiso para eliminarlo"
            });
        }

        const [materiales] = await conexion.query(
            "SELECT id_material FROM material WHERE idTemario = ?",
            [id]
        );

        if (materiales.length > 0) {
            return res.status(409).json({
                mensaje: "No se puede eliminar el temario porque tiene materiales asociados"
            });
        }

        await conexion.query(
            "DELETE FROM temario WHERE id_temario = ?",
            [id]
        );

        res.json({
            mensaje: "Temario eliminado correctamente"
        });

    } catch (error) {
        console.error("Error al eliminar temario:", error);
        res.status(500).json({
            mensaje: "No se pudo eliminar el temario"
        });
    }
};

const obtenerBimestres = async (req, res) => {
    try {
        const [bimestres] = await conexion.query(
            "SELECT id_bime, num FROM bimestre ORDER BY id_bime"
        );

        res.json(bimestres);

    } catch (error) {
        console.error("Error al obtener bimestres:", error);

        res.status(500).json({
            mensaje: "No se pudieron obtener los bimestres"
        });
    }
};

module.exports = {
    obtenerTemarios,
    crearTemario,
    editarTemario,
    eliminarTemario,
    obtenerBimestres
};
