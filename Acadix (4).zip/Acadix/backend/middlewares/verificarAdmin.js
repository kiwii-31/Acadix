// ==========================================
// verificarAdmin
// ==========================================
// Middleware que exige un JWT válido, con rol "administrador",
// en el header Authorization de la request.
//
// Formato esperado del header:
//   Authorization: Bearer <token>
//
// Si el token es válido y el rol es administrador, agrega
// el usuario decodificado en req.usuario y deja pasar (next()).
// Si no, corta la request con 401 (sin token / token inválido)
// o 403 (token válido pero rol distinto de administrador).
// ==========================================

const jwt = require("jsonwebtoken");

const verificarAdmin = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({
            mensaje: "No se proporcionó un token de autenticación"
        });
    }

    const token = authHeader.split(" ")[1];

    try {
        const payload = jwt.verify(token, process.env.JWT_SECRET);

        if (!payload.rol || payload.rol.toLowerCase() !== "administrador") {
            return res.status(403).json({
                mensaje: "No tenés permisos de administrador para esta acción"
            });
        }

        req.usuario = payload;

        next();

    } catch (error) {
        return res.status(401).json({
            mensaje: "Token inválido o expirado"
        });
    }
};

module.exports = verificarAdmin;
