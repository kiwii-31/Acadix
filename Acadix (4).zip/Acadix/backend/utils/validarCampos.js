// ==========================================
// validarCampos
// ==========================================
// Comprueba que un objeto (normalmente req.body) tenga
// todos los campos requeridos, sin repetir el mismo bloque
// de "if (!campo1 || !campo2 || ...)" en cada controller.
//
// Devuelve null si está todo OK, o un array con los nombres
// de los campos faltantes si falta alguno.
//
// Uso:
//   const faltantes = validarCampos(req.body, ["nombre", "apellido", "email"]);
//   if (faltantes) {
//       return res.status(400).json({
//           mensaje: `Faltan campos obligatorios: ${faltantes.join(", ")}`
//       });
//   }
// ==========================================

const validarCampos = (datos, camposRequeridos) => {
    const faltantes = camposRequeridos.filter((campo) => {
        const valor = datos ? datos[campo] : undefined;
        return valor === undefined || valor === null || valor === "";
    });

    return faltantes.length > 0 ? faltantes : null;
};

module.exports = validarCampos;
