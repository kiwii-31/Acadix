// ==========================================
// asyncHandler
// ==========================================
// Envuelve una función de controller (req, res) => {...}
// y captura cualquier error async automáticamente,
// devolviendo una respuesta 500 consistente en vez de
// repetir el mismo try/catch en cada controller.
//
// Uso:
//   const obtenerAlumnos = asyncHandler(async (req, res) => {
//       const [resultados] = await conexion.query(...);
//       res.json(resultados);
//   });
// ==========================================

const asyncHandler = (fn) => {
    return async (req, res, next) => {
        try {
            await fn(req, res, next);
        } catch (error) {
            console.error(`Error en ${req.method} ${req.originalUrl}:`, error);

            res.status(500).json({
                mensaje: "Error interno del servidor",
                error: error.message
            });
        }
    };
};

module.exports = asyncHandler;
