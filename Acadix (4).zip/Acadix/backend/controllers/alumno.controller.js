const conexion = require("../config/db");
const asyncHandler = require("../utils/asyncHandler");
const validarCampos = require("../utils/validarCampos");

// ==========================================
// OBTENER TODOS LOS ALUMNOS
// ==========================================

const obtenerAlumnos = asyncHandler(async (req, res) => {
    const [resultados] = await conexion.query(`
        SELECT
            a.id_alu,
            u.id_user,
            u.nombre,
            u.apellido,
            u.email
        FROM alumno a
        INNER JOIN usuario u ON a.iduser = u.id_user
    `);

    res.json(resultados);
});

// ==========================================
// CREAR ALUMNO
// ==========================================
// El admin crea la cuenta directamente, sin código de
// invitación (a diferencia del auto-registro público en
// auth.controller.js, que sí lo exige).

const crearAlumno = asyncHandler(async (req, res) => {
    const { nombre, apellido, email, password, curso } = req.body;

    const faltantes = validarCampos(req.body, ["nombre", "apellido", "email", "password", "curso"]);

    if (faltantes) {
        return res.status(400).json({
            mensaje: `Faltan campos obligatorios: ${faltantes.join(", ")}`
        });
    }

    const [existentes] = await conexion.query(
        "SELECT id_user FROM usuario WHERE email = ?",
        [email]
    );

    if (existentes.length > 0) {
        return res.status(400).json({
            mensaje: "El email ya está registrado"
        });
    }

    const [cursos] = await conexion.query(
        "SELECT id_curso FROM curso WHERE id_curso = ?",
        [curso]
    );

    if (cursos.length === 0) {
        return res.status(400).json({
            mensaje: "El curso seleccionado no existe"
        });
    }

    const [resultadoUsuario] = await conexion.query(
        `INSERT INTO usuario (nombre, apellido, email, contraseña, cod_invitacion)
         VALUES (?, ?, ?, ?, NULL)`,
        [nombre, apellido, email, password]
    );

    const idUsuario = resultadoUsuario.insertId;

    await conexion.query(
        "INSERT INTO alumno (iduser, idcurso) VALUES (?, ?)",
        [idUsuario, curso]
    );

    res.status(201).json({
        mensaje: "Alumno creado correctamente"
    });
});

// ==========================================
// EDITAR ALUMNO
// ==========================================

const editarAlumno = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { nombre, apellido, email } = req.body;

    const faltantes = validarCampos(req.body, ["nombre", "apellido", "email"]);

    if (faltantes) {
        return res.status(400).json({
            mensaje: `Faltan campos obligatorios: ${faltantes.join(", ")}`
        });
    }

    const [alumno] = await conexion.query(
        "SELECT iduser FROM alumno WHERE id_alu = ?",
        [id]
    );

    if (alumno.length === 0) {
        return res.status(404).json({
            mensaje: "Alumno no encontrado"
        });
    }

    const idUser = alumno[0].iduser;

    await conexion.query(
        `UPDATE usuario
         SET nombre = ?, apellido = ?, email = ?
         WHERE id_user = ?`,
        [nombre, apellido, email, idUser]
    );

    res.json({
        mensaje: "Alumno actualizado correctamente"
    });
});

// ==========================================
// ELIMINAR ALUMNO
// ==========================================

const eliminarAlumno = asyncHandler(async (req, res) => {
    const { id } = req.params;

    const [alumno] = await conexion.query(
        "SELECT iduser FROM alumno WHERE id_alu = ?",
        [id]
    );

    if (alumno.length === 0) {
        return res.status(404).json({
            mensaje: "Alumno no encontrado"
        });
    }

    const idUser = alumno[0].iduser;

    await conexion.query("DELETE FROM alumno WHERE id_alu = ?", [id]);
    await conexion.query("DELETE FROM usuario WHERE id_user = ?", [idUser]);

    res.json({
        mensaje: "Alumno eliminado correctamente"
    });
});

module.exports = {
    obtenerAlumnos,
    crearAlumno,
    editarAlumno,
    eliminarAlumno
};
