const conexion = require("../config/db");
const asyncHandler = require("../utils/asyncHandler");
const validarCampos = require("../utils/validarCampos");

// ==========================================
// Un "curso" se define por año + división + turno.
// La tabla real `turnoxespe` combina turno + especialidad,
// pero la gestión de cursos en esta etapa es básica
// (sin especialidad), así que buscamos o creamos una fila
// de turnoxespe con especialidad NULL para el turno pedido,
// y la usamos como IDTXE del curso. Así el admin nunca ve
// ni maneja turnoxespe directamente.
// ==========================================

const obtenerOCrearTurnoXEspe = async (idTurno) => {
    const [existentes] = await conexion.query(
        "SELECT id_TxE FROM turnoxespe WHERE ID_turno = ? AND ID_espe IS NULL",
        [idTurno]
    );

    if (existentes.length > 0) {
        return existentes[0].id_TxE;
    }

    const [resultado] = await conexion.query(
        "INSERT INTO turnoxespe (ID_turno, ID_espe) VALUES (?, NULL)",
        [idTurno]
    );

    return resultado.insertId;
};

const mapearCurso = (fila) => ({
    id: fila.id_curso,
    idAnio: fila.id_anio,
    anio: fila.anio,
    idDivision: fila.id_div,
    division: fila.division,
    idTurno: fila.id_turno,
    turno: fila.turno
});

// ==========================================
// OBTENER TODOS LOS CURSOS
// ==========================================

const obtenerCursos = asyncHandler(async (req, res) => {
    const [filas] = await conexion.query(`
        SELECT
            c.id_curso,
            an.id_anio,
            an.anio,
            d.id_div,
            d.nombre AS division,
            t.id_turno,
            t.nombre AS turno
        FROM curso c
        LEFT JOIN anio an ON c.IDanio = an.id_anio
        LEFT JOIN division d ON c.IDdiv = d.id_div
        LEFT JOIN turnoxespe tx ON c.IDTXE = tx.id_TxE
        LEFT JOIN turno t ON tx.ID_turno = t.id_turno
    `);

    res.json(filas.map(mapearCurso));
});

// ==========================================
// CREAR CURSO
// ==========================================

const crearCurso = asyncHandler(async (req, res) => {
    const { idAnio, idDivision, idTurno } = req.body;

    const faltantes = validarCampos(req.body, ["idAnio", "idDivision", "idTurno"]);

    if (faltantes) {
        return res.status(400).json({
            mensaje: `Faltan campos obligatorios: ${faltantes.join(", ")}`
        });
    }

    const idTxE = await obtenerOCrearTurnoXEspe(idTurno);

    const [resultado] = await conexion.query(
        "INSERT INTO curso (IDanio, IDdiv, IDTXE) VALUES (?, ?, ?)",
        [idAnio, idDivision, idTxE]
    );

    res.status(201).json({
        mensaje: "Curso creado correctamente",
        id: resultado.insertId
    });
});

// ==========================================
// EDITAR CURSO
// ==========================================

const editarCurso = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { idAnio, idDivision, idTurno } = req.body;

    const faltantes = validarCampos(req.body, ["idAnio", "idDivision", "idTurno"]);

    if (faltantes) {
        return res.status(400).json({
            mensaje: `Faltan campos obligatorios: ${faltantes.join(", ")}`
        });
    }

    const idTxE = await obtenerOCrearTurnoXEspe(idTurno);

    const [resultado] = await conexion.query(
        "UPDATE curso SET IDanio = ?, IDdiv = ?, IDTXE = ? WHERE id_curso = ?",
        [idAnio, idDivision, idTxE, id]
    );

    if (resultado.affectedRows === 0) {
        return res.status(404).json({
            mensaje: "Curso no encontrado"
        });
    }

    res.json({
        mensaje: "Curso actualizado correctamente"
    });
});

// ==========================================
// ELIMINAR CURSO
// ==========================================
// Nota: si el curso tiene alumnos, materias asignadas
// (cursomateria) u otra referencia, esto va a fallar por
// clave foránea (error 500 genérico vía asyncHandler).

const eliminarCurso = asyncHandler(async (req, res) => {
    const { id } = req.params;

    const [resultado] = await conexion.query(
        "DELETE FROM curso WHERE id_curso = ?",
        [id]
    );

    if (resultado.affectedRows === 0) {
        return res.status(404).json({
            mensaje: "Curso no encontrado"
        });
    }

    res.json({
        mensaje: "Curso eliminado correctamente"
    });
});

module.exports = {
    obtenerCursos,
    crearCurso,
    editarCurso,
    eliminarCurso
};
