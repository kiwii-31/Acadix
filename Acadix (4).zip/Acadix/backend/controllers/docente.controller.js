const conexion = require("../config/db");
const asyncHandler = require("../utils/asyncHandler");
const validarCampos = require("../utils/validarCampos");

// ==========================================
// Mapea una fila cruda de la DB (usuario + docente)
// a un objeto consistente en camelCase para el frontend.
// ==========================================

const mapearDocente = (fila) => ({
    id: fila.id_docente,
    idUsuario: fila.id_user,
    nombre: fila.nombre,
    apellido: fila.apellido,
    email: fila.email
});

// ==========================================
// OBTENER TODOS LOS DOCENTES
// ==========================================

const obtenerDocentes = asyncHandler(async (req, res) => {
    const [filas] = await conexion.query(`
        SELECT
            d.id_docente,
            u.id_user,
            u.nombre,
            u.apellido,
            u.email
        FROM docente d
        INNER JOIN usuario u ON d.idusuario = u.id_user
    `);

    res.json(filas.map(mapearDocente));
});

// ==========================================
// CREAR DOCENTE
// ==========================================
// El admin crea la cuenta directamente, sin código de
// invitación (a diferencia del auto-registro público).

const crearDocente = asyncHandler(async (req, res) => {
    const { nombre, apellido, email, password } = req.body;

    const faltantes = validarCampos(req.body, ["nombre", "apellido", "email", "password"]);

    if (faltantes) {
        return res.status(400).json({
            mensaje: `Faltan campos obligatorios: ${faltantes.join(", ")}`
        });
    }

    const [existentes] = await conexion.query(
        "SELECT id_user FROM usuario WHERE email = ?",
        [email]
    );

    if (existentes.length > 0) {
        return res.status(400).json({
            mensaje: "El email ya está registrado"
        });
    }

    const [resultadoUsuario] = await conexion.query(
        `INSERT INTO usuario (nombre, apellido, email, contraseña, cod_invitacion)
         VALUES (?, ?, ?, ?, NULL)`,
        [nombre, apellido, email, password]
    );

    const idUsuario = resultadoUsuario.insertId;

    const [resultadoDocente] = await conexion.query(
        "INSERT INTO docente (idusuario) VALUES (?)",
        [idUsuario]
    );

    res.status(201).json({
        mensaje: "Docente creado correctamente",
        docente: mapearDocente({
            id_docente: resultadoDocente.insertId,
            id_user: idUsuario,
            nombre,
            apellido,
            email
        })
    });
});

// ==========================================
// EDITAR DOCENTE
// ==========================================

const editarDocente = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { nombre, apellido, email } = req.body;

    const faltantes = validarCampos(req.body, ["nombre", "apellido", "email"]);

    if (faltantes) {
        return res.status(400).json({
            mensaje: `Faltan campos obligatorios: ${faltantes.join(", ")}`
        });
    }

    const [docentes] = await conexion.query(
        "SELECT idusuario FROM docente WHERE id_docente = ?",
        [id]
    );

    if (docentes.length === 0) {
        return res.status(404).json({
            mensaje: "Docente no encontrado"
        });
    }

    await conexion.query(
        `UPDATE usuario
         SET nombre = ?, apellido = ?, email = ?
         WHERE id_user = ?`,
        [nombre, apellido, email, docentes[0].idusuario]
    );

    res.json({
        mensaje: "Docente actualizado correctamente"
    });
});

// ==========================================
// ELIMINAR DOCENTE
// ==========================================
// Nota: si el docente tiene asignaciones en asigdocente,
// esto va a fallar por la restricción de clave foránea.
// Por ahora eso se refleja como error 500 genérico
// (vía asyncHandler); no se agregó borrado en cascada.

const eliminarDocente = asyncHandler(async (req, res) => {
    const { id } = req.params;

    const [docentes] = await conexion.query(
        "SELECT idusuario FROM docente WHERE id_docente = ?",
        [id]
    );

    if (docentes.length === 0) {
        return res.status(404).json({
            mensaje: "Docente no encontrado"
        });
    }

    const idUsuario = docentes[0].idusuario;

    await conexion.query("DELETE FROM docente WHERE id_docente = ?", [id]);
    await conexion.query("DELETE FROM usuario WHERE id_user = ?", [idUsuario]);

    res.json({
        mensaje: "Docente eliminado correctamente"
    });
});

module.exports = {
    obtenerDocentes,
    crearDocente,
    editarDocente,
    eliminarDocente
};
