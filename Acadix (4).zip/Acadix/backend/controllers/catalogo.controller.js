const conexion = require("../config/db");
const asyncHandler = require("../utils/asyncHandler");

// ==========================================
// Catálogos de solo lectura, usados para llenar los
// combos del formulario de "crear/editar curso".
// No son gestionables desde el admin en esta etapa
// (se asume que ya están cargados en la base).
// ==========================================

const obtenerAnios = asyncHandler(async (req, res) => {
    const [filas] = await conexion.query(
        "SELECT id_anio, anio FROM anio ORDER BY anio"
    );

    res.json(filas.map((f) => ({ id: f.id_anio, anio: f.anio })));
});

const obtenerDivisiones = asyncHandler(async (req, res) => {
    const [filas] = await conexion.query(
        "SELECT id_div, nombre FROM division ORDER BY nombre"
    );

    res.json(filas.map((f) => ({ id: f.id_div, nombre: f.nombre })));
});

const obtenerTurnos = asyncHandler(async (req, res) => {
    const [filas] = await conexion.query(
        "SELECT id_turno, nombre FROM turno ORDER BY nombre"
    );

    res.json(filas.map((f) => ({ id: f.id_turno, nombre: f.nombre })));
});

module.exports = {
    obtenerAnios,
    obtenerDivisiones,
    obtenerTurnos
};
