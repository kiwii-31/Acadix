const conexion = require("../config/db");
const asyncHandler = require("../utils/asyncHandler");
const validarCampos = require("../utils/validarCampos");

const mapearMateria = (fila) => ({
    id: fila.id_materia,
    nombre: fila.nombre
});

// ==========================================
// OBTENER TODAS LAS MATERIAS
// ==========================================

const obtenerMaterias = asyncHandler(async (req, res) => {
    const [filas] = await conexion.query(
        "SELECT id_materia, nombre FROM materia ORDER BY nombre"
    );

    res.json(filas.map(mapearMateria));
});

// ==========================================
// CREAR MATERIA
// ==========================================

const crearMateria = asyncHandler(async (req, res) => {
    const { nombre } = req.body;

    const faltantes = validarCampos(req.body, ["nombre"]);

    if (faltantes) {
        return res.status(400).json({
            mensaje: `Faltan campos obligatorios: ${faltantes.join(", ")}`
        });
    }

    const [resultado] = await conexion.query(
        "INSERT INTO materia (nombre) VALUES (?)",
        [nombre]
    );

    res.status(201).json({
        mensaje: "Materia creada correctamente",
        materia: mapearMateria({ id_materia: resultado.insertId, nombre })
    });
});

// ==========================================
// EDITAR MATERIA
// ==========================================

const editarMateria = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { nombre } = req.body;

    const faltantes = validarCampos(req.body, ["nombre"]);

    if (faltantes) {
        return res.status(400).json({
            mensaje: `Faltan campos obligatorios: ${faltantes.join(", ")}`
        });
    }

    const [resultado] = await conexion.query(
        "UPDATE materia SET nombre = ? WHERE id_materia = ?",
        [nombre, id]
    );

    if (resultado.affectedRows === 0) {
        return res.status(404).json({
            mensaje: "Materia no encontrada"
        });
    }

    res.json({
        mensaje: "Materia actualizada correctamente"
    });
});

// ==========================================
// ELIMINAR MATERIA
// ==========================================
// Nota: si la materia está vinculada en cursomateria,
// esto va a fallar por la restricción de clave foránea
// (error 500 genérico vía asyncHandler).

const eliminarMateria = asyncHandler(async (req, res) => {
    const { id } = req.params;

    const [resultado] = await conexion.query(
        "DELETE FROM materia WHERE id_materia = ?",
        [id]
    );

    if (resultado.affectedRows === 0) {
        return res.status(404).json({
            mensaje: "Materia no encontrada"
        });
    }

    res.json({
        mensaje: "Materia eliminada correctamente"
    });
});

module.exports = {
    obtenerMaterias,
    crearMateria,
    editarMateria,
    eliminarMateria
};
