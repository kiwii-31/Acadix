const conexion = require("../config/db");
const jwt = require("jsonwebtoken");

// ==========================================
// GENERAR TOKEN
// ==========================================
// Firma un JWT con los datos mínimos necesarios para
// identificar al usuario y su rol en requests futuras.

const generarToken = (usuario) => {
    return jwt.sign(
        {
            id_user: usuario.id_user,
            email: usuario.email,
            rol: usuario.rol
        },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || "8h" }
    );
};

// ==========================================
// INICIAR SESIÓN
// ==========================================

const login = async (req, res) => {
    console.log("LOGIN EJECUTADO");
    console.log("BODY RECIBIDO:", req.body);

    try {
        const { email, password, rol } = req.body;

        if (!email || !password || !rol) {
            return res.status(400).json({
                mensaje: "Email, contraseña y rol son obligatorios"
            });
        }

        // ==========================================
        // LOGIN DE ADMINISTRADOR
        // ==========================================

        if (rol.toLowerCase() === "administrador") {

        const [admins] = await conexion.query(
        `SELECT
            u.id_user,
            u.nombre,
            u.apellido,
            u.email,
            u.contraseña
         FROM usuario u
         INNER JOIN admin a
            ON a.User_ID = u.id_user
         WHERE u.email = ?`,
        [email]
    );

    if (admins.length === 0) {
        return res.status(401).json({
            mensaje: "Email o contraseña incorrectos"
        });
    }

    const admin = admins[0];

    if (admin.contraseña !== password) {
        return res.status(401).json({
            mensaje: "Email o contraseña incorrectos"
        });
    }

    const token = generarToken({
        id_user: admin.id_user,
        email: admin.email,
        rol: "administrador"
    });

    return res.status(200).json({
        mensaje: "Inicio de sesión correcto",
        token,
        usuario: {
            id: admin.id_user,
            nombre: admin.nombre,
            apellido: admin.apellido,
            email: admin.email,
            rol: "administrador"
        }
    });
}

        const [usuarios] = await conexion.query(
            `SELECT
                u.id_user,
                u.nombre,
                u.apellido,
                u.email,
                u.contraseña,
                u.cod_invitacion,
                c.rol,
                c.activo
             FROM usuario u
             LEFT JOIN codigo c
                ON u.cod_invitacion = c.id_codigo
             WHERE u.email = ?`,
            [email]
        );

        if (usuarios.length === 0) {
            return res.status(401).json({
                mensaje: "Email o contraseña incorrectos"
            });
        }

        const usuario = usuarios[0];

        if (usuario.contraseña !== password) {
            return res.status(401).json({
                mensaje: "Email o contraseña incorrectos"
            });
        }

        if (!usuario.rol) {
            return res.status(403).json({
                mensaje: "El usuario no tiene un rol asignado"
            });
        }

        if (usuario.rol.toLowerCase() !== rol.toLowerCase()) {
            return res.status(403).json({
                mensaje: "El rol seleccionado no corresponde al usuario"
            });
        }

        let curso = null;
        let division = null;
        let turno = null;
        let materias = [];

        // ==========================================
        // INFORMACIÓN DEL ALUMNO
        // ==========================================

        if (usuario.rol.toLowerCase() === "alumno") {

            const [alumnos] = await conexion.query(
                `SELECT
                    a.id_alu,
                    c.id_curso,
                    an.anio,
                    d.nombre AS division,
                    t.nombre AS turno
                 FROM alumno a
                 LEFT JOIN curso c
                    ON a.idcurso = c.id_curso
                 LEFT JOIN anio an
                    ON c.IDanio = an.id_anio
                 LEFT JOIN division d
                    ON c.IDdiv = d.id_div
                 LEFT JOIN turnoxespe tx
                    ON c.IDTXE = tx.id_TxE
                 LEFT JOIN turno t
                    ON tx.ID_turno = t.id_turno
                 WHERE a.iduser = ?`,
                [usuario.id_user]
            );

            if (alumnos.length > 0) {

                curso = alumnos[0].anio;
                division = alumnos[0].division;
                turno = alumnos[0].turno;

                const [materiasAlumno] = await conexion.query(
                    `SELECT
                    cm.id_CxM,
                    m.nombre
                    FROM cursomateria cm
                    INNER JOIN materia m
                    ON cm.materia_ID = m.id_materia
                    WHERE cm.curso_ID = ?`,
                    [alumnos[0].id_curso]
                );
                materias = materiasAlumno.map(m => ({
                    idCursoMateria: m.id_CxM,
                    nombre: m.nombre
                }));

            }
        }

        // ==========================================
        // INFORMACIÓN DEL PROFESOR
        // ==========================================

        if (usuario.rol.toLowerCase() === "profesor") {

            const [docentes] = await conexion.query(
                `SELECT id_docente
                 FROM docente
                 WHERE idusuario = ?`,
                [usuario.id_user]
            );

            if (docentes.length > 0) {

                const [datosProfesor] = await conexion.query(
                    `SELECT DISTINCT
                        c.id_curso,
                        an.anio,
                        d.nombre AS division,
                        t.nombre AS turno,
                        cm.id_CxM,
                        m.nombre AS materia
                     FROM asigdocente ad
                     INNER JOIN cursomateria cm
                        ON ad.id_cursoMat = cm.id_CxM
                     INNER JOIN curso c
                        ON cm.curso_ID = c.id_curso
                     INNER JOIN materia m
                        ON cm.materia_ID = m.id_materia
                     LEFT JOIN anio an
                        ON c.IDanio = an.id_anio
                     LEFT JOIN division d
                        ON c.IDdiv = d.id_div
                     LEFT JOIN turnoxespe tx
                        ON c.IDTXE = tx.id_TxE
                     LEFT JOIN turno t
                        ON tx.ID_turno = t.id_turno
                     WHERE ad.profe_id = ?`,
                    [docentes[0].id_docente]
                );

                if (datosProfesor.length > 0) {

                    curso = datosProfesor[0].anio;
                    division = datosProfesor[0].division;
                    turno = datosProfesor[0].turno;

                    materias = datosProfesor.map(item => ({
                        idCursoMateria: item.id_CxM,
                        nombre: item.materia,
                        curso: item.anio,
                        division: item.division,
                        turno: item.turno
                    }));
                }
            }
        }

        const token = generarToken({
            id_user: usuario.id_user,
            email: usuario.email,
            rol: usuario.rol
        });

        return res.status(200).json({
            mensaje: "Inicio de sesión correcto",
            token,

            usuario: {
                id: usuario.id_user,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                email: usuario.email,
                rol: usuario.rol,
                curso: curso,
                division: division,
                turno: turno,
                materias: materias
            }
        });

    } catch (error) {

        console.error("Error en login:", error);

        return res.status(500).json({
            mensaje: "Error interno del servidor",
            error: error.message
        });
    }
};


// ==========================================
// REGISTRAR ALUMNO
// ==========================================

const registrarAlumno = async (req, res) => {

    try {

        const {
            nombre,
            apellido,
            email,
            password,
            codigo,
            curso
        } = req.body;

        // Comprobar datos obligatorios
        if (!nombre || !apellido || !email || !password || !codigo || !curso) {
            return res.status(400).json({
                mensaje: "Todos los campos son obligatorios"
            });
        }

        // Buscar código de invitación
        const [codigos] = await conexion.query(
            `SELECT id_codigo, rol, activo
             FROM codigo
             WHERE cod = ?`,
            [codigo]
        );

        if (codigos.length === 0) {
            return res.status(400).json({
                mensaje: "El código de invitación no existe"
            });
        }

        const codigoInvitacion = codigos[0];

        // Comprobar que el código sea para alumno
        if (
            !codigoInvitacion.rol ||
            codigoInvitacion.rol.toLowerCase() !== "alumno"
        ) {
            return res.status(400).json({
                mensaje: "El código no corresponde a un alumno"
            });
        }

        // Comprobar si el código está activo
        if (
            codigoInvitacion.activo !== null &&
            String(codigoInvitacion.activo).toLowerCase() === "no"
        ) {
            return res.status(400).json({
                mensaje: "El código de invitación está inactivo"
            });
        }

        // Comprobar que el email no exista
        const [usuariosExistentes] = await conexion.query(
            `SELECT id_user
             FROM usuario
             WHERE email = ?`,
            [email]
        );

        if (usuariosExistentes.length > 0) {
            return res.status(400).json({
                mensaje: "El email ya está registrado"
            });
        }

        // Comprobar que el curso exista
        const [cursos] = await conexion.query(
            `SELECT id_curso
             FROM curso
             WHERE id_curso = ?`,
            [curso]
        );

        if (cursos.length === 0) {
            return res.status(400).json({
                mensaje: "El curso seleccionado no existe"
            });
        }

        // Crear usuario
        const [resultadoUsuario] = await conexion.query(
            `INSERT INTO usuario
                (nombre, apellido, email, contraseña, cod_invitacion)
             VALUES (?, ?, ?, ?, ?)`,
            [
                nombre,
                apellido,
                email,
                password,
                codigoInvitacion.id_codigo
            ]
        );

        const idUsuario = resultadoUsuario.insertId;

        // Crear alumno
        await conexion.query(
            `INSERT INTO alumno
                (iduser, idcurso)
             VALUES (?, ?)`,
            [idUsuario, curso]
        );

        return res.status(201).json({
            mensaje: "Cuenta de alumno creada correctamente"
        });

    } catch (error) {

        console.error("Error al registrar alumno:", error);

        return res.status(500).json({
            mensaje: "Error interno del servidor",
            error: error.message
        });
    }
};


// ==========================================
// REGISTRAR DOCENTE
// ==========================================

const registrarDocente = async (req, res) => {

    try {

        const {
            nombre,
            apellido,
            email,
            password,
            codigo
        } = req.body;

        // Comprobar datos obligatorios
        if (!nombre || !apellido || !email || !password || !codigo) {
            return res.status(400).json({
                mensaje: "Todos los campos son obligatorios"
            });
        }

        // Buscar código
        const [codigos] = await conexion.query(
            `SELECT id_codigo, rol, activo
             FROM codigo
             WHERE cod = ?`,
            [codigo]
        );

        if (codigos.length === 0) {
            return res.status(400).json({
                mensaje: "El código de invitación no existe"
            });
        }

        const codigoInvitacion = codigos[0];

        // Comprobar que sea para profesor
        if (
            !codigoInvitacion.rol ||
            codigoInvitacion.rol.toLowerCase() !== "profesor"
        ) {
            return res.status(400).json({
                mensaje: "El código no corresponde a un docente"
            });
        }

        // Comprobar código activo
        if (
            codigoInvitacion.activo !== null &&
            String(codigoInvitacion.activo).toLowerCase() === "no"
        ) {
            return res.status(400).json({
                mensaje: "El código de invitación está inactivo"
            });
        }

        // Comprobar email
        const [usuariosExistentes] = await conexion.query(
            `SELECT id_user
             FROM usuario
             WHERE email = ?`,
            [email]
        );

        if (usuariosExistentes.length > 0) {
            return res.status(400).json({
                mensaje: "El email ya está registrado"
            });
        }

        // Crear usuario
        const [resultadoUsuario] = await conexion.query(
            `INSERT INTO usuario
                (nombre, apellido, email, contraseña, cod_invitacion)
             VALUES (?, ?, ?, ?, ?)`,
            [
                nombre,
                apellido,
                email,
                password,
                codigoInvitacion.id_codigo
            ]
        );

        const idUsuario = resultadoUsuario.insertId;

        // Crear docente
        await conexion.query(
            `INSERT INTO docente
                (idusuario)
             VALUES (?)`,
            [idUsuario]
        );

        return res.status(201).json({
            mensaje: "Cuenta de docente creada correctamente"
        });

    } catch (error) {

        console.error("Error al registrar docente:", error);

        return res.status(500).json({
            mensaje: "Error interno del servidor",
            error: error.message
        });
    }
};


// ==========================================
// EXPORTAR FUNCIONES
// ==========================================

module.exports = {
    login,
    registrarAlumno,
    registrarDocente
};