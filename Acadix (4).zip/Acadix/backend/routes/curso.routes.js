const express = require("express");
const router = express.Router();

const verificarAdmin = require("../middlewares/verificarAdmin");

const {
    obtenerCursos,
    crearCurso,
    editarCurso,
    eliminarCurso
} = require("../controllers/curso.controller");

router.get("/", verificarAdmin, obtenerCursos);

router.post("/", verificarAdmin, crearCurso);

router.put("/:id", verificarAdmin, editarCurso);

router.delete("/:id", verificarAdmin, eliminarCurso);

module.exports = router;
