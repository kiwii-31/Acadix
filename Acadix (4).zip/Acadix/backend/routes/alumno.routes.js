const express = require("express");
const router = express.Router();

const verificarAdmin = require("../middlewares/verificarAdmin");

const {
    obtenerAlumnos,
    crearAlumno,
    editarAlumno,
    eliminarAlumno
} = require("../controllers/alumno.controller");

router.get("/", verificarAdmin, obtenerAlumnos);

router.post("/", verificarAdmin, crearAlumno);

router.put("/:id", verificarAdmin, editarAlumno);

router.delete("/:id", verificarAdmin, eliminarAlumno);

module.exports = router;