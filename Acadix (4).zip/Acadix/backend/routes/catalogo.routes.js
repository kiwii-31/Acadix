const express = require("express");
const router = express.Router();

const verificarAdmin = require("../middlewares/verificarAdmin");

const {
    obtenerAnios,
    obtenerDivisiones,
    obtenerTurnos
} = require("../controllers/catalogo.controller");

router.get("/anios", verificarAdmin, obtenerAnios);

router.get("/divisiones", verificarAdmin, obtenerDivisiones);

router.get("/turnos", verificarAdmin, obtenerTurnos);

module.exports = router;
