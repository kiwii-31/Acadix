const express = require("express");
const router = express.Router();

const verificarAdmin = require("../middlewares/verificarAdmin");

const {
    obtenerDocentes,
    crearDocente,
    editarDocente,
    eliminarDocente
} = require("../controllers/docente.controller");

router.get("/", verificarAdmin, obtenerDocentes);

router.post("/", verificarAdmin, crearDocente);

router.put("/:id", verificarAdmin, editarDocente);

router.delete("/:id", verificarAdmin, eliminarDocente);

module.exports = router;
