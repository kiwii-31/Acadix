const express = require("express");
const router = express.Router();

const verificarAdmin = require("../middlewares/verificarAdmin");

const {
    obtenerMaterias,
    crearMateria,
    editarMateria,
    eliminarMateria
} = require("../controllers/materia.controller");

router.get("/", verificarAdmin, obtenerMaterias);

router.post("/", verificarAdmin, crearMateria);

router.put("/:id", verificarAdmin, editarMateria);

router.delete("/:id", verificarAdmin, eliminarMateria);

module.exports = router;
