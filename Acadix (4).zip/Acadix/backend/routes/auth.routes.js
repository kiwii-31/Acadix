const express = require("express");

const {
    login,
    registrarAlumno,
    registrarDocente
} = require("../controllers/auth.controller");

const router = express.Router();

router.get("/test", (req, res) => {
    res.json({
        mensaje: "Ruta de autenticación funcionando"
    });
});

router.post("/login", login);

router.post("/registro/alumno", registrarAlumno);

router.post("/registro/docente", registrarDocente);

module.exports = router;