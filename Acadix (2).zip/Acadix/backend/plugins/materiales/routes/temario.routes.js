const express = require("express");
const router = express.Router();

const verificarUsuario = require("../middlewares/verificarUsuario");

const {
    obtenerTemarios,
    crearTemario,
    editarTemario,
    eliminarTemario,
    obtenerBimestres
} = require("../controllers/temario.controller");

router.use(verificarUsuario);

router.get("/", obtenerTemarios);
router.post("/", crearTemario);
router.put("/:id", editarTemario);
router.delete("/:id", eliminarTemario);
router.get("/bimestres", verificarUsuario, obtenerBimestres);

module.exports = router;
