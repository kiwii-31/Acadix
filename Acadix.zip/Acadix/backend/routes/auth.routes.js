const express = require("express");
const { login } = require("../controllers/auth.controller");

const router = express.Router();

router.get("/test", (req, res) => {
    res.json({
        mensaje: "Ruta de autenticación funcionando"
    });
});

router.post("/login", login);

module.exports = router;