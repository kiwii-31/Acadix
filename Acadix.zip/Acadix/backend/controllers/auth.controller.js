const conexion = require("../config/db");

const login = async (req, res) => {
    console.log("LOGIN EJECUTADO");
    console.log("BODY RECIBIDO:", req.body);

    try {
        const { email, password, rol } = req.body;

        if (!email || !password || !rol) {
            return res.status(400).json({
                mensaje: "Email, contraseña y rol son obligatorios"
            });
        }

        // ==========================================
        // BUSCAR USUARIO Y ROL
        // ==========================================

        const [usuarios] = await conexion.query(
            `SELECT
                u.id_user,
                u.nombre,
                u.apellido,
                u.email,
                u.contraseña,
                u.cod_invitacion,
                c.rol,
                c.activo
             FROM usuario u
             LEFT JOIN codigo c
                ON u.cod_invitacion = c.id_codigo
             WHERE u.email = ?`,
            [email]
        );

        if (usuarios.length === 0) {
            return res.status(401).json({
                mensaje: "Email o contraseña incorrectos"
            });
        }

        const usuario = usuarios[0];

        // ==========================================
        // COMPROBAR CONTRASEÑA
        // ==========================================

        if (usuario.contraseña !== password) {
            return res.status(401).json({
                mensaje: "Email o contraseña incorrectos"
            });
        }

        // ==========================================
        // COMPROBAR ROL
        // ==========================================

        if (!usuario.rol) {
            return res.status(403).json({
                mensaje: "El usuario no tiene un rol asignado"
            });
        }

        if (usuario.rol.toLowerCase() !== rol.toLowerCase()) {
            return res.status(403).json({
                mensaje: "El rol seleccionado no corresponde al usuario"
            });
        }

        // ==========================================
        // INFORMACIÓN DEL ALUMNO
        // ==========================================

        let curso = null;
        let division = null;
        let turno = null;
        let materias = [];

        if (usuario.rol.toLowerCase() === "alumno") {

            const [alumnos] = await conexion.query(
                `SELECT
                    a.id_alu,
                    c.id_curso,
                    an.anio,
                    d.nombre AS division,
                    t.nombre AS turno
                 FROM alumno a
                 LEFT JOIN curso c
                    ON a.idcurso = c.id_curso
                 LEFT JOIN anio an
                    ON c.IDanio = an.id_anio
                 LEFT JOIN division d
                    ON c.IDdiv = d.id_div
                 LEFT JOIN turnoxespe tx
                    ON c.IDTXE = tx.id_TxE
                 LEFT JOIN turno t
                    ON tx.ID_turno = t.id_turno
                 WHERE a.iduser = ?`,
                [usuario.id_user]
            );

            if (alumnos.length > 0) {
                curso = alumnos[0].anio;
                division = alumnos[0].division;
                turno = alumnos[0].turno;

                // Buscar materias del curso del alumno
                const [materiasAlumno] = await conexion.query(
                    `SELECT m.nombre
                     FROM cursomateria cm
                     INNER JOIN materia m
                        ON cm.materia_ID = m.id_materia
                     WHERE cm.curso_ID = ?`,
                    [alumnos[0].id_curso]
                );

                materias = materiasAlumno.map(m => m.nombre);
            }
        }

        // ==========================================
        // INFORMACIÓN DEL PROFESOR
        // ==========================================

        if (usuario.rol.toLowerCase() === "profesor") {

            const [docentes] = await conexion.query(
                `SELECT id_docente
                 FROM docente
                 WHERE idusuario = ?`,
                [usuario.id_user]
            );

            if (docentes.length > 0) {

                const [datosProfesor] = await conexion.query(
                    `SELECT DISTINCT
                        c.id_curso,
                        an.anio,
                        d.nombre AS division,
                        t.nombre AS turno,
                        m.nombre AS materia
                     FROM asigdocente ad
                     INNER JOIN cursomateria cm
                        ON ad.id_cursoMat = cm.id_CxM
                     INNER JOIN curso c
                        ON cm.curso_ID = c.id_curso
                     INNER JOIN materia m
                        ON cm.materia_ID = m.id_materia
                     LEFT JOIN anio an
                        ON c.IDanio = an.id_anio
                     LEFT JOIN division d
                        ON c.IDdiv = d.id_div
                     LEFT JOIN turnoxespe tx
                        ON c.IDTXE = tx.id_TxE
                     LEFT JOIN turno t
                        ON tx.ID_turno = t.id_turno
                     WHERE ad.profe_id = ?`,
                    [docentes[0].id_docente]
                );

                if (datosProfesor.length > 0) {

                    curso = datosProfesor[0].anio;
                    division = datosProfesor[0].division;
                    turno = datosProfesor[0].turno;

                    materias = datosProfesor.map(item => ({
    nombre: item.materia,
    curso: item.anio,
    division: item.division,
    turno: item.turno
}));
                }
            }
        }

        // ==========================================
        // RESPUESTA FINAL
        // ==========================================

        return res.status(200).json({
            mensaje: "Inicio de sesión correcto",

            usuario: {
                id: usuario.id_user,
                nombre: usuario.nombre,
                apellido: usuario.apellido,
                email: usuario.email,
                rol: usuario.rol,

                curso: curso,
                division: division,
                turno: turno,
                materias: materias
            }
        });

    } catch (error) {

        console.error("Error en login:", error);

        return res.status(500).json({
            mensaje: "Error interno del servidor",
            error: error.message
        });
    }
};

module.exports = {
    login
};