const express = require("express");
const cors = require("cors");
const conexion = require("./config/db");
const authRoutes = require("./routes/auth.routes");

const app = express();

app.use(cors());
app.use(express.json());
app.use("/api/auth", authRoutes);

// Ruta principal
app.get("/", (req, res) => {
    res.json({
        mensaje: "Servidor de Acadix funcionando correctamente"
    });
});

// Ruta para probar la conexión con MySQL
app.get("/api/test-db", async (req, res) => {
    try {
        const [resultado] = await conexion.query("SELECT 1 AS conectado");

        res.json({
            mensaje: "Conexión con MySQL funcionando",
            resultado: resultado
        });

    } catch (error) {
        console.error("Error al conectar con MySQL:", error);

        res.status(500).json({
            mensaje: "Error al conectar con MySQL",
            error: error.message
        });
    }
});

// Iniciar servidor
const PORT = 3000;

app.listen(PORT, () => {
    console.log(`Servidor de Acadix ejecutándose en http://localhost:${PORT}`);
});