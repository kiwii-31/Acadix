import { useState } from "react";
import "./App.css";

function App() {
  // =====================================================
  // ESTADOS GENERALES
  // =====================================================

  const [pantalla, setPantalla] = useState("inicio");
  const [rol, setRol] = useState("");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [usuario, setUsuario] = useState(null);

  const [mensaje, setMensaje] = useState("");
  const [cargando, setCargando] = useState(false);
  const [loginCorrecto, setLoginCorrecto] = useState(false);

  // =====================================================
  // FILTROS DEL PROFESOR
  // =====================================================

  const [filtroAnio, setFiltroAnio] = useState("");
  const [filtroDivision, setFiltroDivision] = useState("");
  const [filtroTurno, setFiltroTurno] = useState("");

  // =====================================================
  // SELECCIONAR ROL
  // =====================================================

  const seleccionarRol = (rolSeleccionado) => {
    setRol(rolSeleccionado);

    setMensaje("");
    setEmail("");
    setPassword("");

    setLoginCorrecto(false);
    setUsuario(null);

    // Limpiar filtros del profesor
    setFiltroAnio("");
    setFiltroDivision("");
    setFiltroTurno("");

    setPantalla("login");
  };

  // =====================================================
  // INICIAR SESIÓN
  // =====================================================

  const iniciarSesion = async (e) => {
    e.preventDefault();

    setMensaje("");
    setLoginCorrecto(false);
    setCargando(true);

    try {
      const respuesta = await fetch(
        "http://localhost:3000/api/auth/login",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email,
            password,
            rol,
          }),
        }
      );

      const datos = await respuesta.json();

      if (!respuesta.ok) {
        setMensaje(datos.mensaje || "Error al iniciar sesión");
        return;
      }

      console.log("Usuario logueado:", datos.usuario);
      console.log("Materias:", datos.usuario.materias);

      setUsuario(datos.usuario);
      setMensaje(`¡Bienvenido/a ${datos.usuario.nombre}!`);
      setLoginCorrecto(true);

      // Limpiar filtros cada vez que inicia sesión
      setFiltroAnio("");
      setFiltroDivision("");
      setFiltroTurno("");

      // Ir al panel correspondiente
      if (datos.usuario.rol.toLowerCase() === "alumno") {
        setPantalla("panelAlumno");
      } else if (datos.usuario.rol.toLowerCase() === "profesor") {
        setPantalla("panelProfesor");
      } else {
        setMensaje("Rol no reconocido");
      }

    } catch (error) {
      console.error("Error:", error);
      setMensaje("No se pudo conectar con el servidor");

    } finally {
      setCargando(false);
    }
  };

  // =====================================================
  // CERRAR SESIÓN
  // =====================================================

  const cerrarSesion = () => {
    setPantalla("inicio");

    setRol("");
    setEmail("");
    setPassword("");

    setUsuario(null);

    setMensaje("");
    setLoginCorrecto(false);

    setFiltroAnio("");
    setFiltroDivision("");
    setFiltroTurno("");
  };

  // =====================================================
  // VOLVER AL INICIO
  // =====================================================

  const volverInicio = () => {
    setPantalla("inicio");

    setRol("");
    setEmail("");
    setPassword("");

    setUsuario(null);

    setMensaje("");
    setLoginCorrecto(false);

    setFiltroAnio("");
    setFiltroDivision("");
    setFiltroTurno("");
  };

  // =====================================================
  // DATOS DEL PROFESOR
  // =====================================================

  const materiasProfesor = usuario?.materias || [];

  // Años disponibles
  const aniosDisponibles = [
    ...new Set(
      materiasProfesor.map((materia) => materia.curso)
    ),
  ];

  // Divisiones disponibles
  const divisionesDisponibles = [
    ...new Set(
      materiasProfesor.map((materia) => materia.division)
    ),
  ];

  // Turnos disponibles
  const turnosDisponibles = [
    ...new Set(
      materiasProfesor.map((materia) => materia.turno)
    ),
  ];

  // =====================================================
  // FILTRAR MATERIAS DEL PROFESOR
  // =====================================================

  const materiasFiltradas = materiasProfesor.filter((materia) => {

    const coincideAnio =
      filtroAnio === "" ||
      String(materia.curso) === String(filtroAnio);

    const coincideDivision =
      filtroDivision === "" ||
      String(materia.division) === String(filtroDivision);

    const coincideTurno =
      filtroTurno === "" ||
      String(materia.turno) === String(filtroTurno);

    return (
      coincideAnio &&
      coincideDivision &&
      coincideTurno
    );
  });

  // =====================================================
  // RETURN
  // =====================================================

  return (
    <div className="app">

      {/* =================================================
          INICIO
      ================================================= */}

      {pantalla === "inicio" && (
        <div className="inicio">

          <div className="inicio-contenedor">

            <header className="inicio-header">
              <h1>ACADIX</h1>
            </header>

            <div className="inicio-contenido">

              <div className="inicio-imagen">
                <img
                  src="/escuela.jpg"
                  alt="Escuela Técnica"
                />
              </div>

              <div className="inicio-info">

                <div className="texto-inicio">

                  <h2>
                    BIENVENIDO A
                    <span>ACADIX</span>
                  </h2>

                  <p>
                    Descubre nuestra plataforma diseñada
                    para potenciar tu éxito. Explora, conecta y
                    gestiona tus productos con facilidad
                  </p>

                </div>

                <div className="inicio-botones">

                  <button
                    className="crear-cuenta"
                    onClick={() => {
                      alert(
                        "La creación de cuenta estará disponible próximamente."
                      );
                    }}
                  >
                    CREAR CUENTA
                  </button>

                  <button
                    className="iniciar-sesion"
                    onClick={() => setPantalla("roles")}
                  >
                    INICIAR SESION
                  </button>

                </div>

              </div>

            </div>

          </div>

        </div>
      )}

      {/* =================================================
          SELECCIÓN DE ROL
      ================================================= */}

      {pantalla === "roles" && (
        <div className="pantalla">

          <div className="contenedor">

            <h1>ACADIX</h1>

            <h2>Seleccioná tu rol</h2>

            <p>
              Elegí cómo vas a ingresar a la plataforma.
            </p>

            <button
              className="boton"
              onClick={() => seleccionarRol("alumno")}
            >
              Alumno
            </button>

            <button
              className="boton"
              onClick={() => seleccionarRol("profesor")}
            >
              Profesor
            </button>

            <button
              className="boton"
              onClick={() => seleccionarRol("administrador")}
            >
              Administrador
            </button>

            <button
              className="boton volver"
              onClick={volverInicio}
            >
              Volver
            </button>

          </div>

        </div>
      )}

      {/* =================================================
          LOGIN
      ================================================= */}

      {pantalla === "login" && (
        <div className="pantalla">

          <div className="contenedor login">

            <h1>ACADIX</h1>

            <h2>Iniciar sesión</h2>

            <p>
              Rol seleccionado:
              <strong> {rol}</strong>
            </p>

            <form onSubmit={iniciarSesion}>

              <input
                type="email"
                placeholder="Correo electrónico"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />

              <input
                type="password"
                placeholder="Contraseña"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />

              <button
                className="boton principal"
                type="submit"
                disabled={cargando}
              >
                {cargando
                  ? "Ingresando..."
                  : "Ingresar"}
              </button>

            </form>

            {mensaje && (
              <p
                className={
                  loginCorrecto
                    ? "mensaje correcto"
                    : "mensaje error"
                }
              >
                {mensaje}
              </p>
            )}

            <button
              className="boton volver"
              onClick={() => setPantalla("roles")}
            >
              Cambiar rol
            </button>

          </div>

        </div>
      )}

      {/* =================================================
          PANEL ALUMNO
      ================================================= */}

      {pantalla === "panelAlumno" && usuario && (
        <div className="pantalla pantalla-alumno">

          <div className="contenedor panel panel-alumno">

            {/* LOGO */}

            <h1>ACADIX</h1>

            {/* PANEL LATERAL */}

            <div className="alumno-lateral">

              <div className="titulo-alumno">
                👤 PANEL DE ALUMNO
              </div>

              <div className="nombre-alumno">
                {usuario.nombre} {usuario.apellido}
              </div>

              <div className="dato-alumno">
                Año: {usuario.curso || "No disponible"}
              </div>

              <div className="dato-alumno">
                División: {usuario.division || "No disponible"}
              </div>

            </div>

            {/* CONTENIDO */}

            <div className="alumno-contenido">

              <h2>
                Mis materias
              </h2>

              <div className="materias-alumno">

                {usuario.materias &&
                usuario.materias.length > 0 ? (

                  usuario.materias.map((materia, index) => (

                    <div
                      className="materia-alumno"
                      key={index}
                    >
                      {typeof materia === "string"
                        ? materia
                        : materia.nombre}
                    </div>

                  ))

                ) : (

                  <p className="sin-materias">
                    No hay materias asignadas.
                  </p>

                )}

              </div>

            </div>

            {/* CERRAR SESIÓN */}

            <button
              className="cerrar-alumno"
              onClick={cerrarSesion}
            >
              Cerrar sesión
            </button>

          </div>

        </div>
      )}

      {/* =================================================
          PANEL PROFESOR
      ================================================= */}

      {pantalla === "panelProfesor" && usuario && (
        <div className="pantalla pantalla-profesor">

          <div className="contenedor panel panel-profesor">

            {/* LOGO */}

            <h1>ACADIX</h1>

            {/* PANEL LATERAL */}

            <div className="profesor-lateral">

              <div className="titulo-profesor">
                👤 PANEL DE PROFESOR
              </div>

              <h3>
                GESTIÓN DE CLASES
              </h3>

              {/* AÑO */}

              <select
                value={filtroAnio}
                onChange={(e) =>
                  setFiltroAnio(e.target.value)
                }
              >

                <option value="">
                  Año Asignado
                </option>

                {aniosDisponibles.map(
                  (anio, index) => (

                    <option
                      value={anio}
                      key={index}
                    >
                      {anio}
                    </option>

                  )
                )}

              </select>

              {/* DIVISIÓN */}

              <select
                value={filtroDivision}
                onChange={(e) =>
                  setFiltroDivision(e.target.value)
                }
              >

                <option value="">
                  División
                </option>

                {divisionesDisponibles.map(
                  (division, index) => (

                    <option
                      value={division}
                      key={index}
                    >
                      {division}
                    </option>

                  )
                )}

              </select>

              {/* TURNO */}

              <select
                value={filtroTurno}
                onChange={(e) =>
                  setFiltroTurno(e.target.value)
                }
              >

                <option value="">
                  Turno
                </option>

                {turnosDisponibles.map(
                  (turno, index) => (

                    <option
                      value={turno}
                      key={index}
                    >
                      {turno}
                    </option>

                  )
                )}

              </select>

              {/* LIMPIAR FILTROS */}

              <button
                className="limpiar-filtros"
                onClick={() => {
                  setFiltroAnio("");
                  setFiltroDivision("");
                  setFiltroTurno("");
                }}
              >
                Limpiar filtros
              </button>

            </div>

            {/* CONTENIDO */}

            <div className="profesor-contenido">

              <h2>
                Mis Materias
              </h2>

              <div className="materias-profesor">

                {materiasFiltradas.length > 0 ? (

                  materiasFiltradas.map(
                    (materia, index) => (

                      <div
                        className="materia-profesor"
                        key={index}
                      >
                        {materia.nombre}
                      </div>

                    )
                  )

                ) : (

                  <p className="sin-asignaciones">
                    No hay materias para los filtros
                    seleccionados.
                  </p>

                )}

              </div>

            </div>

            {/* CERRAR SESIÓN */}

            <button
              className="cerrar-profesor"
              onClick={cerrarSesion}
            >
              Cerrar sesión
            </button>

          </div>

        </div>
      )}

    </div>
  );
}

export default App;