USE acadix;

-- ==========================================
-- DATOS DE PRUEBA - ACADIX
-- ==========================================

-- Código de alumno
INSERT INTO codigo (cod, rol, activo)
SELECT 'ALUMNO123', 'alumno', 1
WHERE NOT EXISTS (
    SELECT 1
    FROM codigo
    WHERE cod = 'ALUMNO123'
);

-- Código de profesor
INSERT INTO codigo (cod, rol, activo)
SELECT 'PROFESOR123', 'profesor', 1
WHERE NOT EXISTS (
    SELECT 1
    FROM codigo
    WHERE cod = 'PROFESOR123'
);

-- Usuario alumno
INSERT INTO usuario
(nombre, apellido, email, contraseña, cod_invitacion)
SELECT
'Prueba',
'Alumno',
'prueba@gmail.com',
'123456',
id_codigo
FROM codigo
WHERE cod = 'ALUMNO123'
AND NOT EXISTS (
    SELECT 1
    FROM usuario
    WHERE email = 'prueba@gmail.com'
);

-- Usuario profesor
INSERT INTO usuario
(nombre, apellido, email, contraseña, cod_invitacion)
SELECT
'Juan',
'Profesor',
'profesor@gmail.com',
'Profesor123',
id_codigo
FROM codigo
WHERE cod = 'PROFESOR123'
AND NOT EXISTS (
    SELECT 1
    FROM usuario
    WHERE email = 'profesor@gmail.com'
);

-- Relacionar profesor con docente
INSERT INTO docente (idusuario)
SELECT u.id_user
FROM usuario u
WHERE u.email = 'profesor@gmail.com'
AND NOT EXISTS (
    SELECT 1
    FROM docente d
    WHERE d.idusuario = u.id_user
);